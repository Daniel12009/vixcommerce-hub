import requests
import time
import concurrent.futures
import pandas as pd
from datetime import datetime, timedelta
import pytz 
from collections import Counter
from database import obter_conta, atualizar_conta
from google_sheets import append_data_to_sheet, get_gsheet_client
import traceback

# Configurações de Sessão
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
retry_strategy = Retry(total=4, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
adapter = HTTPAdapter(max_retries=retry_strategy)
session = requests.Session()
session.mount("https://", adapter)

# Mapa de Estados
MAPA_ESTADOS = {
    'AC': 'Acre', 'AL': 'Alagoas', 'AP': 'Amapá', 'AM': 'Amazonas', 'BA': 'Bahia',
    'CE': 'Ceará', 'DF': 'Distrito Federal', 'ES': 'Espírito Santo', 'GO': 'Goiás',
    'MA': 'Maranhão', 'MT': 'Mato Grosso', 'MS': 'Mato Grosso do Sul', 'MG': 'Minas Gerais',
    'PA': 'Pará', 'PB': 'Paraíba', 'PR': 'Paraná', 'PE': 'Pernambuco', 'PI': 'Piauí',
    'RJ': 'Rio de Janeiro', 'RN': 'Rio Grande do Norte', 'RS': 'Rio Grande do Sul',
    'RO': 'Rondônia', 'RR': 'Roraima', 'SC': 'Santa Catarina', 'SP': 'São Paulo',
    'SE': 'Sergipe', 'TO': 'Tocantins'
}

def traduzir_estado(entrada):
    if not entrada: return "Não Identificado"
    entrada = str(entrada).strip().upper()
    if len(entrada) == 2: return MAPA_ESTADOS.get(entrada, entrada)
    return entrada.title()

# --- FUNÇÃO DE FORMATAÇÃO DE DATA ---
def formatar_data_br(iso_date):
    """Converte data ISO para DD/MM/YYYY considerando Fuso -3"""
    if not iso_date: return ''
    try:
        # Define fuso BR
        tz_br = pytz.timezone('America/Sao_Paulo')
        
        if 'T' in iso_date:
            # Converte de string para datetime (UTC)
            dt_utc = datetime.fromisoformat(iso_date.replace('Z', '+00:00'))
            if dt_utc.tzinfo is None: dt_utc = pytz.utc.localize(dt_utc)
            
            # Converte para BR
            dt_br = dt_utc.astimezone(tz_br)
            return dt_br.strftime('%d/%m/%Y')
        else:
            dt = datetime.strptime(iso_date[:10], '%Y-%m-%d')
            return dt.strftime('%d/%m/%Y')
    except Exception:
        return iso_date[:10] if iso_date else ''

def formatar_moeda(valor):
    """Formata float para string BR (1.250,50)"""
    if valor is None: return "0,00"
    return f"{valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

def get_headers(token):
    clean_token = str(token).strip()
    return {
        "Authorization": f"Bearer {clean_token}",
        "Content-Type": "application/json"
    }

def renovar_token_ml(client_id, client_secret, refresh_token):
    url = "https://api.mercadolibre.com/oauth/token"
    headers = {'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json'}
    data = {'grant_type': 'refresh_token', 'client_id': client_id, 'client_secret': client_secret, 'refresh_token': refresh_token}
    resp = session.post(url, headers=headers, data=data)
    if resp.status_code == 200: return resp.json()
    else: raise Exception(f"Erro renovação ML: {resp.text}")

def get_valid_access_token(user_id):
    conta = obter_conta(user_id)
    if not conta: raise Exception("Conta não encontrada.")
    if conta.get('access_token'):
        try:
            h = {"Authorization": f"Bearer {conta['access_token']}"}
            r = session.get("https://api.mercadolibre.com/users/me", headers=h)
            if r.status_code == 200:
                return conta['access_token']
        except: pass
    print(f"🔄 Renovando token para {user_id}...")
    novos = renovar_token_ml(conta['client_id'], conta['client_secret'], conta['refresh_token'])
    atualizar_conta(user_id, {'access_token': novos['access_token'], 'refresh_token': novos['refresh_token']})
    return novos['access_token']

def consultar_frete(ship_id, headers):
    # Alterado para retornar também a CIDADE
    if not ship_id: return 0.0, "", "Não Identificado", ""
    try:
        r = session.get(f"https://api.mercadolibre.com/shipments/{ship_id}", headers=headers)
        if r.status_code == 200:
            d = r.json()
            free_shipping = d.get('free_shipping', False)
            cost_opt = float(d.get('shipping_option', {}).get('cost', 0) or 0)
            list_cost = float(d.get('shipping_option', {}).get('list_cost', 0) or 0)
            base_cost = float(d.get('base_cost', 0) or 0)
            custo_final = 0.0
            if free_shipping: custo_final = cost_opt
            else:
                referencia_cheia = list_cost if list_cost > 0 else base_cost
                if referencia_cheia > 0: custo_final = max(0.0, referencia_cheia - cost_opt)
            
            rec = d.get('receiver_address', {})
            est_sigla = rec.get('state', {}).get('name') or rec.get('city', {}).get('state_name') or ""
            est = traduzir_estado(est_sigla)
            
            # --- NOVO: Extrair Cidade ---
            cidade = rec.get('city', {}).get('name', '')
            
            ltype = d.get('logistic_type')
            tags = d.get('tags', [])
            mode = d.get('mode')
            tipo = "Mercado Envios"
            if ltype == 'fulfillment': tipo = "Mercado Envios Full"
            elif ltype in ['self_service', 'flex'] or 'self_service_in' in tags or mode == 'me1': tipo = "Mercado Envios Flex"
            elif ltype == 'cross_docking': tipo = "Mercado Envios Coleta"
            elif ltype in ['drop_off', 'xd_drop_off']: tipo = "Mercado Envios Agência"

            return custo_final, est, tipo, cidade
    except: pass
    return 0.0, "", "Mercado Envios", ""

# --- PROCESSAMENTO INDIVIDUAL ---
def processar_venda_ml_single(venda, headers, data_inicio_filtro, data_fim_filtro, contagem_packs):
    try:
        if venda.get('status') == 'cancelled': return []

        # 1. VERIFICAÇÃO RIGOROSA DE DATA (FUSO BRASIL)
        try:
            tz_br = pytz.timezone('America/Sao_Paulo')
            dt_venda_str = venda.get('date_created')
            if dt_venda_str:
                dt_venda = datetime.fromisoformat(dt_venda_str.replace('Z', '+00:00'))
                if dt_venda.tzinfo is None: dt_venda = pytz.utc.localize(dt_venda)
                
                dt_venda_br = dt_venda.astimezone(tz_br)
                
                if not (data_inicio_filtro <= dt_venda_br <= data_fim_filtro):
                    return [] # Pula venda de outro dia
        except Exception as e:
             print(f"Erro data: {e}")
             pass

        # 2. DEFINIÇÃO DE IDs
        vid = venda.get('id')
        pid = venda.get('pack_id')
        sid = venda.get('shipping', {}).get('id')
        
        id_referencia_pedido = str(vid)
        
        if pid:
            qtd_no_carrinho = contagem_packs.get(pid, 0)
            if qtd_no_carrinho == 1:
                id_referencia_pedido = str(pid)
            else:
                pass 

        if not sid and pid:
            try:
                rp = session.get(f"https://api.mercadolibre.com/packs/{pid}", headers=headers)
                if rp.status_code == 200: sid = rp.json().get('shipment', {}).get('id')
            except: pass
        
        if not sid and not pid:
            try:
                rs = session.get(f"https://api.mercadolibre.com/orders/{vid}/shipments", headers=headers)
                if rs.status_code == 200:
                    shipments = rs.json().get('shipments', [])
                    if shipments: sid = shipments[0].get('id')
            except: pass

        # AGORA RECEBE CIDADE TAMBÉM
        custo_api, estado, tipo_log, cidade_dest = consultar_frete(sid, headers)
        
        linhas = []
        for item in venda.get('order_items', []):
            item_obj = item.get('item', {})
            sku = item_obj.get('seller_custom_field') or item_obj.get('seller_sku') or item_obj.get('id')
            titulo = item_obj.get('title', '-')

            preco = float(item.get('unit_price', 0))
            qtd = int(item.get('quantity', 1))
            valor_total_item = preco * qtd
            
            if tipo_log != 'Mercado Envios Flex':
                node = item.get('stock', {}).get('node_id')
                if node and str(node).startswith('BR'): tipo_log = 'Mercado Envios Full'

            custo_calc = 0.0
            
            # --- NOVA LÓGICA DO FLEX (CURITIBA VS OUTROS) ---
            if tipo_log == 'Mercado Envios Flex':
                cidade_limpa = str(cidade_dest).strip().lower()
                
                # Regra 1: Curitiba
                if 'curitiba' in cidade_limpa:
                    if valor_total_item <= 79.00:
                        custo_calc = 0.00
                    else:
                        custo_calc = 8.01
                # Regra 2: Flex Fora de Curitiba
                else:
                    if valor_total_item <= 79.00:
                        custo_calc = 5.00
                    else:
                        custo_calc = 12.81
                        
            elif tipo_log == 'Mercado Envios Full':
                custo_calc = 0.0 if valor_total_item < 79.00 else custo_api
            else:
                custo_calc = 0.0 if valor_total_item < 79.00 else custo_api

            if tipo_log != 'Mercado Envios Flex' and custo_api == 0: custo_calc = 0.0
            
            # Transforma em negativo para a planilha
            if custo_calc > 0: custo_calc *= -1
            custo_calc = round(custo_calc, 2)

            if not estado:
                try:
                    rb = session.get(f"https://api.mercadolibre.com/orders/{vid}/billing_info", headers=headers)
                    if rb.status_code==200:
                        est_raw = rb.json().get('billing_info',{}).get('address',{}).get('state_name','')
                        estado = traduzir_estado(est_raw)
                except: pass
            if not estado: estado = "Não Identificado"

            fee = float(item.get('sale_fee', 0))
            fee_total_neg = -1 * (fee * qtd) if fee > 0 else (fee * qtd)
            
            data_criacao = formatar_data_br(venda.get('date_created'))
            data_fechamento = formatar_data_br(venda.get('date_closed'))
            id_venda_str = f"'{id_referencia_pedido}"

            linhas.append([
                sku, sku, data_criacao, data_fechamento, id_venda_str,
                "Mercado Livre", item_obj.get('id'),
                "Clássico" if 'gold_special' in str(item.get('listing_type_id')) else "Premium",
                "", tipo_log, preco, qtd, valor_total_item, custo_calc, 0, fee_total_neg,
                "", venda.get('seller', {}).get('nickname'), estado
            ])
        return linhas
    except:
        traceback.print_exc()
        return []

def executar_sincronizacao_ml(user_id, google_creds_json, google_creds_file, d_ini, d_fim, spreadsheet_id_override=None, sheet_name_override=None):
    
    conta = obter_conta(user_id)
    if not conta: return {"sucesso": False, "mensagem": f"Conta {user_id} não encontrada."}
    
    sheet_id = spreadsheet_id_override or conta.get('spreadsheet_id')
    sheet_name = sheet_name_override or conta.get('sheet_name') or 'VendasML'
    
    if not sheet_id: return {"sucesso": False, "mensagem": "ID da planilha não configurado."}

    try:
        token = get_valid_access_token(user_id)
        headers = get_headers(token)
    except Exception as e:
        return {"sucesso": False, "mensagem": f"Erro de Token: {str(e)}"}

    try:
        me_resp = session.get("https://api.mercadolibre.com/users/me", headers=headers)
        if me_resp.status_code != 200:
            return {"sucesso": False, "mensagem": f"Erro ID Vendedor: {me_resp.text}"}
        seller_id = me_resp.json().get('id')
    except Exception as e:
        return {"sucesso": False, "mensagem": f"Erro fatal User ID: {str(e)}"}

    # 3. CONFIGURAÇÃO DE DATAS E FUSOS (CORREÇÃO DE FUSO PARA API E FILTRO)
    tz_br = pytz.timezone('America/Sao_Paulo')
    
    d_ini_iso = f"{d_ini}T00:00:00.000-03:00"
    d_fim_iso = f"{d_fim}T23:59:59.999-03:00"
    
    dt_ini_obj = tz_br.localize(datetime.strptime(d_ini, '%Y-%m-%d').replace(hour=0, minute=0, second=0, microsecond=0))
    dt_fim_obj = tz_br.localize(datetime.strptime(d_fim, '%Y-%m-%d').replace(hour=23, minute=59, second=59, microsecond=999999))

    from google_sheets import get_gsheet_client
    client = get_gsheet_client(config={'GOOGLE_CREDENTIALS_FILE': google_creds_file})
    
    offset, limit = 0, 50
    todas_vendas = []
    
    # 4. DOWNLOAD DAS VENDAS
    while True:
        url = f"https://api.mercadolibre.com/orders/search?seller={str(seller_id)}&order.date_created.from={d_ini_iso}&order.date_created.to={d_fim_iso}&sort=date_desc&limit={limit}&offset={offset}"
        try:
            r = session.get(url, headers=headers)
            if r.status_code != 200: raise Exception(f"Erro API: {r.text}")
            res = r.json().get('results', [])
            if not res: break
            
            todas_vendas.extend(res)
            
            if len(res) < limit: break
            offset += limit
            time.sleep(0.3)
        except Exception as e:
            return {"sucesso": False, "mensagem": f"Erro no download: {str(e)}"}
    
    if not todas_vendas:
        return {"sucesso": True, "mensagem": f"Nenhuma venda encontrada no período."}

    # 5. CONTAGEM PARA REGRA DE ID (Pack vs Single)
    lista_packs = [v.get('pack_id') for v in todas_vendas if v.get('pack_id')]
    contagem_packs = Counter(lista_packs)

    # 6. PROCESSAMENTO COM FILTRO E REGRAS
    lote_linhas = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        futures = {executor.submit(processar_venda_ml_single, v, headers, dt_ini_obj, dt_fim_obj, contagem_packs): v for v in todas_vendas}
        
        for f in concurrent.futures.as_completed(futures):
            resultado = f.result()
            if resultado: lote_linhas.extend(resultado)
    
    if lote_linhas:
        df = pd.DataFrame(lote_linhas)
        append_data_to_sheet(client, df, sheet_id, sheet_name)
    
    return {"sucesso": True, "mensagem": f"Sucesso! {len(lote_linhas)} vendas filtradas e processadas."}
