from database import init_db, salvar_conta, listar_contas, excluir_conta, atualizar_conta, obter_conta
import requests

# --- FUNÇÃO CRÍTICA PARA RENOVAÇÃO DE TOKEN ML (MANTIDA INTACTA) ---
def get_valid_access_token(user_id):
    conta = obter_conta(user_id)
    if not conta:
        raise Exception(f"Conta ML {user_id} não encontrada para renovação de token.")

    access_token = conta.get('access_token')
    
    if access_token and access_token != 'inicial':
        return access_token 

    url = "https://api.mercadolibre.com/oauth/token"
    headers = {'accept': 'application/json', 'content-type': 'application/x-www-form-urlencoded'}
    
    payload = {
        'grant_type': 'refresh_token',
        'client_id': conta['client_id'],
        'client_secret': conta['client_secret'],
        'refresh_token': conta['refresh_token']
    }

    try:
        resp = requests.post(url, headers=headers, data=payload)
        resp.raise_for_status()
        dados_auth = resp.json()

        novo_token = dados_auth['access_token']
        novo_refresh_token = dados_auth['refresh_token'] 

        atualizar_conta(user_id, {
            'access_token': novo_token,
            'refresh_token': novo_refresh_token
        })
        
        return novo_token
    
    except requests.exceptions.RequestException as e:
        print(f"Erro ao renovar token ML para {user_id}: {e}")
        raise Exception(f"Falha na renovação do token do Mercado Livre.")

# --- IMPORTAÇÃO DO MERCADO LIVRE (INTACTO) ---
try:
    from mercadolibre_api import executar_sincronizacao_ml
except ImportError:
    def executar_sincronizacao_ml(*args, **kwargs): return {"sucesso": False, "mensagem": "Módulo ML indisponível."}
    
# --- IMPORTAÇÃO DO NOVO MÓDULO TINY (Substitui Shopee, Amazon, Shein e Tiktok) ---
try:
    from tiny_api import executar_sincronizacao_tiny
except ImportError:
    def executar_sincronizacao_tiny(*args, **kwargs): return {"sucesso": False, "mensagem": "Módulo Tiny indisponível."}


# --- ROUTER PRINCIPAL ---
def processar_envio_vendas(user_id, google_creds_json, google_creds_file, 
                           data_inicio_custom=None, data_fim_custom=None, plataforma=None, modo=None, 
                           spreadsheet_id_override=None, sheet_name_override=None):
    
    try:
        if not plataforma:
            conta = obter_conta(user_id)
            if conta: plataforma = conta.get('plataforma')
        
        if not plataforma:
            return {"sucesso": False, "mensagem": "Plataforma não definida para esta conta."} 

        # Args comuns que todos os módulos precisam:
        common_args = [user_id, google_creds_json, google_creds_file, data_inicio_custom, data_fim_custom]
        
        # Args de override para o destino final
        override_kwargs = {
            "spreadsheet_id_override": spreadsheet_id_override,
            "sheet_name_override": sheet_name_override
        }

        plataforma_formatada = plataforma.lower().strip()

        if plataforma_formatada == 'mercadolibre':
            # Chama o módulo nativo do Mercado Livre (Não alterado)
            return executar_sincronizacao_ml(*common_args, **override_kwargs)
            
        elif plataforma_formatada in ['shopee', 'amazon', 'shein', 'tiktok', 'temu']: # ⬅️ TEMU ADICIONADA AQUI!
            # Desvia todas as outras plataformas para o HUB central do Tiny ERP
            return executar_sincronizacao_tiny(*common_args, plataforma=plataforma_formatada, **override_kwargs)
            
        else:
            return {"sucesso": False, "mensagem": f"Plataforma '{plataforma}' não suportada."}
            
    except Exception as e:
        return {"sucesso": False, "mensagem": f"Erro Geral VendasGS: {str(e)}"}
