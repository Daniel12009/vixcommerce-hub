import pandas as pd
import time
import schedule
import pytz
import traceback
from datetime import datetime, timedelta, date
import os
import json

# SDK oficial Google GenAI
from google import genai
from google.genai import types

# Importações dos seus módulos originais - AJUSTADO PARA OS NOMES REAIS
from google_sheets import get_gsheet_client, write_data_to_sheet, read_data_from_sheet
from database import listar_contas
from VendasGS import processar_envio_vendas
from performance import gerar_relatorio_performance_v2
from marketing import buscar_dados_ads_api # <--- NOME CORRETO CONFORME SEU APP.PY

# --- CONFIGURAÇÕES DE AMBIENTE ---
SHEET_ID_LOG_AGENTES = '1CczRWwLsLcjMcER9kAoLxpIcj3YzvMP5YKgcuDTFimM'
SHEET_ID_DASHBOARD = '1ynblqNNpHSAsFo7dIsOzQgK9ltv52d7sIufl3wpZZ0w'
FUSO_BR = pytz.timezone('America/Sao_Paulo')

client_gemini = genai.Client(api_key=os.environ.get("GEMINI_API_KEY"))

response_schema_ads = {
    "type": "OBJECT",
    "properties": {
        "acoes": {
            "type": "ARRAY",
            "items": {
                "type": "OBJECT",
                "properties": {
                    "Campanha": {"type": "STRING"},
                    "SKU_Principal": {"type": "STRING"},
                    "Investimento": {"type": "STRING"},
                    "ROAS_Atual": {"type": "STRING"},
                    "Acao": {"type": "STRING"},
                    "Observacao": {"type": "STRING"}
                },
                "required": ["Campanha", "SKU_Principal", "Acao", "Observacao"]
            }
        }
    }
}

# --- FUNÇÕES AUXILIARES ---
def garantir_aba(gs_client, sheet_id, nome_aba, colunas_cabecalho):
    sh = gs_client.open_by_key(sheet_id)
    try:
        ws = sh.worksheet(nome_aba)
    except:
        ws = sh.add_worksheet(title=nome_aba, rows=1000, cols=len(colunas_cabecalho))
        ws.update('A1', [colunas_cabecalho])
    return ws

def formatar_nome_conta(nome_bruto):
    nome = str(nome_bruto).upper().replace(" ", "")
    if "VIA" in nome or "FLIX" in nome: return "VIAFLIX"
    if "GS" in nome: return "GS"
    if "MONACO" in nome or "DECARION" in nome: return "MONACO"
    return nome[:10]

# ==============================================================================
#  FUNÇÃO CENTRAL: AGENTE ANALISTA ADS
# ==============================================================================

def agente_analista_ads():
    print(f"🤖 [IA] Iniciando Ciclo Completo ML: {datetime.now(FUSO_BR)}")
    try:
        gs_client = get_gsheet_client({'GOOGLE_CREDENTIALS_FILE': 'credentials.json'})
        contas = listar_contas()
        
        hoje = date.today()
        ontem = (hoje - timedelta(days=1)).strftime('%Y-%m-%d')
        sete_dias_atras = (hoje - timedelta(days=7)).strftime('%Y-%m-%d')

        for conta in contas:
            if str(conta.get('plataforma', '')).upper() != 'MERCADO_LIVRE':
                continue

            nome_original = conta['nome_conta']
            user_id = conta.get('user_id')
            aba_ads_log = f"ADS-{formatar_nome_conta(nome_original)}"
            
            print(f"🚀 >>> GATILHO ML: {nome_original} <<<")

            # 1. DISPARO DE VENDAS
            processar_envio_vendas(
                user_id=user_id, 
                google_creds_file='credentials.json', 
                data_inicio_custom=sete_dias_atras, 
                data_fim_custom=ontem
            )

            # 2. DISPARO DE ADS (marketing.py) - AJUSTADO PARA buscar_dados_ads_api
            print(f"📢 [2/4] Sincronizando ADS de ontem...")
            buscar_dados_ads_api(user_id, ontem, ontem, "all") # "all" conforme padrão do seu módulo

            # 3. DISPARO DE PERFORMANCE
            gerar_relatorio_performance_v2(user_id, 'conversao', {"periodo": "7d"})

            # 4. ANÁLISE IA GEMINI
            df_vendas_ia = read_data_from_sheet(gs_client, SHEET_ID_DASHBOARD, 'VENDAS')
            df_ads_ia = read_data_from_sheet(gs_client, SHEET_ID_DASHBOARD, 'teste luiz ADS')
            
            df_vendas_conta = df_vendas_ia[df_vendas_ia['Conta'].str.contains(nome_original, na=False, case=False)]
            
            garantir_aba(gs_client, SHEET_ID_LOG_AGENTES, aba_ads_log, ['Campanha', 'SKU Principal', 'Investimento', 'ROAS Atual', 'Ação', 'Observação'])
            
            prompt = f"Analise a conta {nome_original}. Vendas 7d: {df_vendas_conta.to_json(orient='records')}. Ads Ontem: {df_ads_ia.to_json(orient='records')}."
            
            try:
                resposta = client_gemini.models.generate_content(
                    model='gemini-2.0-flash',
                    contents=prompt,
                    config=types.GenerateContentConfig(
                        response_mime_type="application/json",
                        response_schema=response_schema_ads,
                        temperature=0.1
                    )
                )
                df_ia = pd.DataFrame(json.loads(resposta.text).get("acoes", []))
                if not df_ia.empty:
                    df_ia.rename(columns={"SKU_Principal": "SKU Principal", "ROAS_Atual": "ROAS Atual", "Observacao": "Observação"}, inplace=True)
                    write_data_to_sheet(gs_client, df_ia, SHEET_ID_LOG_AGENTES, aba_ads_log)
            except Exception as e:
                print(f"❌ Erro IA {nome_original}: {e}")

            time.sleep(90)

        print("✅ CICLO AUTOMÁTICO FINALIZADO.")
    except Exception as e:
        print(f"❌ Erro Crítico no Agente: {traceback.format_exc()}")

# ==============================================================================
#  ORQUESTRADOR
# ==============================================================================

def iniciar_orquestrador():
    print(f"🚀 Orquestrador IA iniciado. Servidor em UTC, operando para Brasília.")
    
    while True:
        # Pega a hora atual em Brasília
        agora_br = datetime.now(FUSO_BR)
        
        # Se for 06:00 da manhã (e nos primeiros 60 segundos desse minuto)
        if agora_br.hour == 6 and agora_br.minute == 0:
            print(f"⏰ Hora de trabalhar! Disparando rotina de Brasília: {agora_br}")
            try:
                rotina_mercado_livre_completa()
            except Exception as e:
                print(f"❌ Erro na execução agendada: {e}")
            
            # Espera 65 segundos para não disparar duas vezes no mesmo minuto
            time.sleep(65)
        
        # Verifica a cada 30 segundos
        time.sleep(30)

if __name__ == "__main__":
    iniciar_orquestrador()
