# google_sheets.py (V18.4 - Correção Final: update + col_values)
import gspread
from google.oauth2.service_account import Credentials
import pandas as pd
import os
import traceback

SCOPES = [
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/drive.file'
]

# --- IDs Fixos REMOVIDOS daqui. Eles são passados pelo app.py ---

def get_gsheet_client(config):
    # (Função sem alterações)
    credentials_file = config.get('GOOGLE_CREDENTIALS_FILE', 'credentials.json')
    credentials_path = os.path.abspath(credentials_file)
    print(f"--- DEBUG: Tentando carregar credenciais de: {credentials_path}")
    if not os.path.exists(credentials_path):
         print(f"--- ERRO CRÍTICO: Arquivo de credenciais '{credentials_path}' não encontrado. ---")
         return None
    try:
        creds = Credentials.from_service_account_file(credentials_path, scopes=SCOPES)
        print("--- DEBUG: Credenciais carregadas com sucesso. ---")
        client = gspread.authorize(creds)
        print("--- DEBUG: Cliente Google Sheets autenticado com sucesso. ---")
        return client
    except Exception as e:
        print(f"--- ERRO ao autenticar com Google Sheets: {e} ---")
        traceback.print_exc()
        return None

# Função read_data_from_sheet (Usa ID e Nome passados)
def read_data_from_sheet(client, sheet_id, worksheet_name):
    if not client: return pd.DataFrame()
    try:
        print(f"--- DEBUG: Tentando ler: Planilha ID='{sheet_id}', Aba='{worksheet_name}' ---")
        spreadsheet = client.open_by_key(sheet_id)
        print(f"--- DEBUG: Planilha ID='{sheet_id}' aberta com sucesso. Nome: '{spreadsheet.title}' ---")
        worksheet = spreadsheet.worksheet(worksheet_name)
        print(f"--- DEBUG: Aba '{worksheet_name}' acessada com sucesso. ---")
        data = worksheet.get_all_records()
        if not data: print(f"--- AVISO: Nenhum dado encontrado na planilha ID '{sheet_id}' / aba '{worksheet_name}'. ---"); return pd.DataFrame()
        df = pd.DataFrame(data); print(f"--- INFO: Dados lidos com sucesso da planilha ID '{sheet_id}'. {len(df)} linhas. ---"); return df
    except gspread.exceptions.APIError as api_error: print(f"--- ERRO API Google: {api_error}. Verifique o ID da planilha e o compartilhamento. ---"); return pd.DataFrame()
    except gspread.exceptions.WorksheetNotFound: print(f"--- ERRO: Aba '{worksheet_name}' não encontrada na planilha ID '{sheet_id}'. ---"); return pd.DataFrame()
    except Exception as e: print(f"--- ERRO ao ler dados da planilha: {e} ---"); traceback.print_exc(); return pd.DataFrame()

# Função write_data_to_sheet (Corrigida para começar em start_column)
def write_data_to_sheet(client, df, sheet_id, worksheet_name, start_column='A'):
    if not client: return False
    try:
        print(f"--- DEBUG: Tentando escrever (substituir): Planilha ID='{sheet_id}', Aba='{worksheet_name}', Coluna Inicial='{start_column}' ---")
        spreadsheet = client.open_by_key(sheet_id)
        print(f"--- DEBUG: Planilha ID='{sheet_id}' aberta com sucesso. Nome: '{spreadsheet.title}' ---")
        worksheet = spreadsheet.worksheet(worksheet_name)
        print(f"--- DEBUG: Aba '{worksheet_name}' acessada com sucesso. ---")
        
        # Limpa APENAS da coluna P em diante
        start_col_index = gspread.utils.a1_to_rowcol(f"{start_column}1")[1]
        total_cols = worksheet.col_count
        # Constrói o range P1:AG... (ou F1:Z...)
        end_col_letter = gspread.utils.rowcol_to_a1(1, max(total_cols, start_col_index + len(df.columns) - 1)).split('1')[0]
        range_to_clear = f"{start_column}1:{end_col_letter}{worksheet.row_count}"
        print(f"--- DEBUG: Limpando range {range_to_clear} ---")
        try:
            worksheet.clear_basic(range_to_clear)
        except Exception as clear_e:
             print(f"--- AVISO: Não foi possível limpar o range (pode estar vazio). Continuando. Erro: {clear_e} ---")

        start_cell = f"{start_column}1"
        data_to_write = [df.columns.values.tolist()] + df.values.tolist()
            
        print(f"--- DEBUG: Preparando para escrever {len(data_to_write)} linhas a partir de {start_cell} (USER_ENTERED). ---")
        
        # Adiciona linhas se necessário (para write)
        total_rows_needed = len(data_to_write)
        if total_rows_needed > worksheet.row_count:
            print(f"--- DEBUG: Planilha tem {worksheet.row_count} linhas. Adicionando {total_rows_needed - worksheet.row_count + 1} novas linhas. ---")
            worksheet.add_rows(total_rows_needed - worksheet.row_count + 1)

        worksheet.update(data_to_write, start_cell, value_input_option='USER_ENTERED')
        
        print(f"--- INFO: Dados escritos (substituídos) com sucesso na planilha ID '{sheet_id}', começando em {start_cell}. {len(df)} linhas de dados. ---")
        return True
    except gspread.exceptions.APIError as api_error: print(f"--- ERRO API Google: {api_error}. Verifique o ID da planilha e o compartilhamento. ---"); traceback.print_exc(); return False
    except gspread.exceptions.WorksheetNotFound: print(f"--- ERRO: Aba '{worksheet_name}' não encontrada na planilha ID '{sheet_id}'. ---"); return False
    except Exception as e: print(f"--- ERRO ao escrever dados na planilha: {e} ---"); traceback.print_exc(); return False

# --- FUNÇÃO APPEND CORRIGIDA (V18.4 - Usando update + Célula P/F) ---
def append_data_to_sheet(client, df, sheet_id, worksheet_name, start_column='A'):
    """Adiciona os dados do DataFrame à planilha, começando na start_column da próxima linha vazia."""
    if not client: return False
    try:
        start_col_index = gspread.utils.a1_to_rowcol(f"{start_column}1")[1] # Coluna 1-based (P=16, F=6)

        print(f"--- DEBUG: Tentando adicionar dados via update: Planilha ID='{sheet_id}', Aba='{worksheet_name}', Coluna Inicial='{start_column}' (Índice {start_col_index}) ---")

        spreadsheet = client.open_by_key(sheet_id)
        print(f"--- DEBUG: Planilha ID='{sheet_id}' aberta com sucesso. Nome: '{spreadsheet.title}' ---")
        worksheet = spreadsheet.worksheet(worksheet_name)
        print(f"--- DEBUG: Aba '{worksheet_name}' acessada com sucesso. ---")

        # --- CORREÇÃO: Encontra a próxima linha vazia BASEADO NA COLUNA START_COLUMN ---
        print(f"--- DEBUG: Verificando valores da coluna {start_column} (Índice {start_col_index}) para encontrar linha vazia... ---")
        col_values = worksheet.col_values(start_col_index)
        next_row = len(col_values) + 1 # A próxima linha é o total de linhas + 1 NESSA COLUNA
        print(f"--- DEBUG: Próxima linha vazia (baseado na Col {start_column}) encontrada: {next_row} ---")
        # --- FIM CORREÇÃO ---

        # Verifica se precisa incluir cabeçalho (se a célula inicial P1 ou F1 está vazia)
        header_cell = f"{start_column}1"
        include_header = False
        try:
             include_header = not worksheet.acell(header_cell).value
        except gspread.exceptions.CellNotFound:
             include_header = True # Célula nem existe, então está vazia
        except Exception as e_acell:
             print(f"--- AVISO: Não foi possível verificar {header_cell} (erro: {e_acell}). Assumindo que cabeçalho existe. ---")
             include_header = False


        data_to_write = []
        if include_header:
             data_to_write = [df.columns.values.tolist()] + df.values.tolist()
             print(f"--- DEBUG: Célula {header_cell} vazia, adicionando cabeçalho. ---")
             start_cell = header_cell # Começa em P1 ou F1
        else:
             data_to_write = df.values.tolist()
             print(f"--- DEBUG: Célula {header_cell} preenchida, adicionando apenas dados. ---")
             start_cell = f"{start_column}{next_row}" # Começa em P/F + next_row

        if not data_to_write:
             print("--- INFO: Nenhum dado novo para adicionar à planilha. ---"); return True

        # ANTES de escrever, verifica se precisa adicionar linhas
        total_rows_needed = (next_row - 1) + len(data_to_write)
        if total_rows_needed > worksheet.row_count:
            rows_to_add = total_rows_needed - worksheet.row_count + 1 # Adiciona 1 extra por segurança
            print(f"--- DEBUG: Planilha tem {worksheet.row_count} linhas. Adicionando {rows_to_add} novas linhas. ---")
            worksheet.add_rows(rows_to_add) # Adiciona linhas extras
        
        print(f"--- DEBUG: Chamando update com {len(data_to_write)} linhas, começando em {start_cell}, value_input_option='USER_ENTERED'. ---")
        worksheet.update(data_to_write, start_cell, value_input_option='USER_ENTERED')

        print(f"--- INFO: {len(data_to_write) - (1 if include_header else 0)} linhas de dados adicionadas/atualizadas com sucesso na planilha ID '{sheet_id}', começando em {start_cell}. ---")
        return True
    except gspread.exceptions.APIError as api_error: print(f"--- ERRO API Google: {api_error}. Verifique o ID da planilha e o compartilhamento. ---"); traceback.print_exc(); return False
    except gspread.exceptions.WorksheetNotFound: print(f"--- ERRO: Aba '{worksheet_name}' não encontrada na planilha ID '{sheet_id}'. ---"); return False
    except Exception as e: print(f"--- ERRO ao adicionar dados à planilha: {e} ---"); traceback.print_exc(); return False

