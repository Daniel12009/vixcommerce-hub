import pandas as pd
import requests
import concurrent.futures
import traceback
from datetime import datetime, timedelta

# Importa dependências
try:
    from database import obter_conta
    from google_sheets import get_gsheet_client
except ImportError:
    pass

# --- CONFIGURAÇÃO ---
SHEET_ID_PERFORMANCE = '1lMq5aeInwwv7st8-Rf-S8NYQJaQKkSbSD7PjtFhtPms' 

def get_headers(token):
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

# --- AUTENTICAÇÃO ---
def renovar_token_ml(client_id, client_secret, refresh_token):
    url = "https://api.mercadolibre.com/oauth/token"
    headers = {'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json'}
    data = {'grant_type': 'refresh_token', 'client_id': client_id, 'client_secret': client_secret, 'refresh_token': refresh_token}
    resp = requests.post(url, headers=headers, data=data)
    if resp.status_code == 200: return resp.json()
    else: raise Exception(f"Erro token: {resp.text}")

def get_valid_access_token(user_id):
    conta = obter_conta(user_id)
    if not conta: raise Exception("Conta não encontrada.")
    if conta.get('access_token'):
        try:
            r = requests.get("https://api.mercadolibre.com/users/me", headers={"Authorization": f"Bearer {conta['access_token']}"})
            if r.status_code == 200: return conta['access_token']
        except: pass
    
    print(f"🔄 Renovando token para {user_id}...")
    novos = renovar_token_ml(conta['client_id'], conta['client_secret'], conta['refresh_token'])
    try:
        from database import atualizar_conta
        atualizar_conta(user_id, {'access_token': novos['access_token'], 'refresh_token': novos['refresh_token']})
    except: pass
    return novos['access_token']

# ==============================================================================
#                       MÓDULO 1: PERFORMANCE (CONSOLIDADA OFICIAL)
# ==============================================================================

def buscar_itens_catalogo_full_ml(user_id, token):
    headers = get_headers(token)
    item_ids = []
    offset = 0; limit = 50
    while True:
        try:
            url = f"https://api.mercadolibre.com/users/{user_id}/items/search?status=active&logistic_type=fulfillment&catalog_listing=true&limit={limit}&offset={offset}"
            r = requests.get(url, headers=headers)
            if r.status_code != 200: break
            res = r.json().get('results', [])
            if not res: break
            item_ids.extend(res)
            if len(res) < limit: break
            offset += limit
        except: break
    return item_ids

def buscar_detalhes_itens_ml(item_ids, token):
    headers = get_headers(token)
    detalhes = {}
    
    chunks = [item_ids[i:i + 20] for i in range(0, len(item_ids), 20)]
    for chunk in chunks:
        try:
            ids_str = ",".join(chunk)
            r = requests.get(f"https://api.mercadolibre.com/items?ids={ids_str}&attributes=id,title,permalink,seller_custom_field,attributes", headers=headers)
            if r.status_code == 200:
                for item in r.json():
                    if item.get('code') == 200:
                        b = item.get('body', {})
                        mlb = b.get('id')
                        sku = b.get('seller_custom_field')
                        if not sku:
                            for a in b.get('attributes', []):
                                if a.get('id') == 'SELLER_SKU': sku = a.get('value_name'); break
                        detalhes[mlb] = {'sku': sku if sku else 'SEM_SKU', 'titulo': b.get('title'), 'link': b.get('permalink'), 'preco': 0}
        except: pass

    def fetch_price(mlb):
        try:
            r = requests.get(f"https://api.mercadolibre.com/items/{mlb}/sale_price?context=channel_marketplace", headers=headers, timeout=5)
            if r.status_code == 200: return mlb, float(r.json().get('amount', 0))
        except: pass
        return mlb, 0

    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        for fut in concurrent.futures.as_completed([executor.submit(fetch_price, m) for m in item_ids]):
            m, p = fut.result()
            if m in detalhes and p > 0: detalhes[m]['preco'] = p
    return detalhes

def obter_visitas_ml(item_ids, token, dt_inicio, dt_fim):
    visitas = {m: 0 for m in item_ids}
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    
    # FORMATOS EXATOS DA DOCUMENTAÇÃO (YYYY-MM-DD)
    date_from = dt_inicio.strftime('%Y-%m-%d')
    date_to = dt_fim.strftime('%Y-%m-%d')

    # FUNÇÃO DE BUSCA 1 POR 1 (A documentação proíbe mandar lote neste endpoint)
    def fetch_visitas_oficial(mlb):
        url = f"https://api.mercadolibre.com/items/visits?ids={mlb}&date_from={date_from}&date_to={date_to}"
        try:
            r = requests.get(url, headers=headers, timeout=5)
            if r.status_code == 200:
                dados = r.json()
                
                # A documentação mostra que o Mercado Livre retorna um dicionário direto ou lista
                if isinstance(dados, dict):
                    return mlb, int(dados.get('total_visits', 0))
                elif isinstance(dados, list) and len(dados) > 0:
                    return mlb, int(dados[0].get('total_visits', 0))
        except: pass
        return mlb, 0

    # DISPARA MÚLTIPLAS REQUISIÇÕES SIMULTÂNEAS PARA SER RÁPIDO
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as exc:
        for fut in concurrent.futures.as_completed([exc.submit(fetch_visitas_oficial, m) for m in item_ids]):
            m, v = fut.result()
            visitas[m] = v
            
    return visitas

def mapear_vendas_ml(user_id, token, item_ids, dt_inicio, dt_fim):
    headers = get_headers(token)
    
    date_from = dt_inicio.strftime('%Y-%m-%dT00:00:00.000-03:00')
    date_to = dt_fim.strftime('%Y-%m-%dT23:59:59.999-03:00')
    
    vendas = {m: {'total': 0, 'canceladas': 0} for m in item_ids}
    set_items = set(item_ids)
    offset = 0; limit = 50
    
    while True:
        try:
            url = f"https://api.mercadolibre.com/orders/search?seller={user_id}&order.date_created.from={date_from}&order.date_created.to={date_to}&limit={limit}&offset={offset}"
            r = requests.get(url, headers=headers)
            if r.status_code != 200: break
            results = r.json().get('results', [])
            if not results: break
            
            for o in results:
                st = o.get('status')
                if st in ['paid', 'confirmed', 'payment_required', 'cancelled']:
                    for i in o.get('order_items', []):
                        mid = i.get('item', {}).get('id')
                        if mid in set_items:
                            vendas[mid]['total'] += 1
                            if st == 'cancelled': vendas[mid]['canceladas'] += 1
            if len(results) < limit: break
            offset += limit
        except: break
    return vendas

def executar_analise_mercadolibre(user_id, conta, dt_inicio, dt_fim):
    token = get_valid_access_token(user_id)
    items = buscar_itens_catalogo_full_ml(user_id, token)
    if not items: return False, "Nenhum item Full encontrado."
    
    det = buscar_detalhes_itens_ml(items, token)
    
    str_periodo = f"{dt_inicio.strftime('%d/%m/%Y')} a {dt_fim.strftime('%d/%m/%Y')}"
    print(f"   📅 Processando período CONSOLIDADO: {str_periodo}")
    
    vis = obter_visitas_ml(items, token, dt_inicio, dt_fim)
    ven = mapear_vendas_ml(user_id, token, items, dt_inicio, dt_fim)
    
    dados_finais = []
    
    for m in items:
        d = det.get(m, {})
        v = vis.get(m, 0)
        s = ven.get(m, {'total': 0, 'canceladas': 0})
        conv = (s['total'] / v) if v > 0 else 0.0
        
        preco_fmt = f"R$ {d.get('preco', 0):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        conv_fmt = f"{conv * 100:.2f}%".replace('.', ',')
        
        dados_finais.append({
            'Plataforma': 'Mercado Livre', 
            'ID Anúncio': m, 
            'SKU': d.get('sku', ''), 
            'Título': d.get('titulo', ''),
            'Preço': preco_fmt, 
            'Visitas': v, 
            'Vendas': s['total'], 
            'Canceladas': s['canceladas'], 
            'Conversão %': conv_fmt, 
            'Link': d.get('link', ''), 
            'Conta': conta['nome_conta'], 
            'Data Ref': str_periodo
        })
            
    return pd.DataFrame(dados_finais)

# ==============================================================================
#                       MÓDULO 2: VENDAS FULL (SEPARADO POR ABA)
# ==============================================================================

def buscar_vendas_full_7dias(user_id, conta):
    print(f"\n📦 [FULL] Iniciando busca para {conta['nome_conta']}...")
    try:
        token = get_valid_access_token(user_id)
        headers = get_headers(token)
        
        agora = datetime.utcnow() - timedelta(hours=3)
        date_from = (agora - timedelta(days=7)).strftime('%Y-%m-%dT00:00:00.000-03:00')
        date_to = agora.strftime('%Y-%m-%dT23:59:59.999-03:00')
        
        vendas_sku = {}
        offset = 0; limit = 50
        
        while True:
            url = f"https://api.mercadolibre.com/orders/search?seller={user_id}&order.date_created.from={date_from}&order.date_created.to={date_to}&limit={limit}&offset={offset}"
            try:
                r = requests.get(url, headers=headers)
                if r.status_code != 200: break
                results = r.json().get('results', [])
                if not results: break
                
                for o in results:
                    if o.get('status') not in ['paid', 'confirmed', 'payment_required']: continue
                    is_fulfilled = o.get('fulfilled') is True
                    if not is_fulfilled:
                        for item in o.get('order_items', []):
                            if item.get('stock', {}).get('node_id'): is_fulfilled = True; break
                    if not is_fulfilled: continue 
                    for i in o.get('order_items', []):
                        qtd = int(i.get('quantity', 0))
                        chave = i.get('item', {}).get('seller_sku') or i.get('item', {}).get('id')
                        if chave: vendas_sku[chave] = vendas_sku.get(chave, 0) + qtd
                if len(results) < limit or offset > 5000: break
                offset += limit
            except: break

        if not vendas_sku: return {"sucesso": True, "mensagem": "Nenhuma venda Full encontrada."}

        # Resolve MLB -> SKU
        mlbs = [k for k in vendas_sku.keys() if str(k).startswith('MLB')]
        mapa = {}
        if mlbs:
            chunks = [mlbs[i:i+20] for i in range(0, len(mlbs), 20)]
            for chunk in chunks:
                try:
                    r = requests.get(f"https://api.mercadolibre.com/items?ids={','.join(chunk)}&attributes=id,seller_custom_field,attributes", headers=headers)
                    if r.status_code == 200:
                        for i in r.json():
                            if i.get('code') == 200:
                                b = i.get('body', {})
                                msku = b.get('seller_custom_field')
                                if not msku:
                                    for a in b.get('attributes', []): 
                                        if a.get('id') == 'SELLER_SKU': msku = a.get('value_name'); break
                                mapa[b.get('id')] = msku if msku else b.get('id')
                except: pass

        lista_final = []
        nome_conta_str = conta['nome_conta'].upper()
        for k, qtd in vendas_sku.items():
            real_sku = mapa.get(k, k) if str(k).startswith('MLB') else k
            lista_final.append({'Conta': nome_conta_str, 'SKU': real_sku if real_sku else "SEM_SKU", 'Unidades Vendidas (7d)': qtd, 'Data Ref': datetime.now().strftime('%d/%m/%Y')})
            
        df_novo = pd.DataFrame(lista_final)
        client = get_gsheet_client({'GOOGLE_CREDENTIALS_FILE': 'credentials.json'})
        sh = client.open_by_key(SHEET_ID_PERFORMANCE)
        
        nome_aba_destino = f"V7-{nome_conta_str}"[:30] 
        try: ws = sh.worksheet(nome_aba_destino)
        except: ws = sh.add_worksheet(title=nome_aba_destino, rows=1000, cols=6)
        
        ws.clear()
        ws.update([df_novo.columns.values.tolist()] + df_novo.values.tolist())

        return {"sucesso": True, "mensagem": f"Sucesso! Aba '{nome_aba_destino}' atualizada com {len(lista_final)} registros."}

    except Exception as e:
        traceback.print_exc()
        return {"sucesso": False, "mensagem": f"Erro interno: {str(e)}"}

# ==============================================================================
#                       ROTEADOR PRINCIPAL (V2)
# ==============================================================================

def gerar_relatorio_performance_v2(user_id, tipo_relatorio, opcoes=None):
    try:
        conta = obter_conta(user_id)
        if not conta: return {"sucesso": False, "mensagem": "Conta não encontrada."}
        
        if tipo_relatorio == 'vendas_full':
            return buscar_vendas_full_7dias(user_id, conta)
            
        else:
            # LÓGICA DE DATAS DE CONSOLIDAÇÃO
            if opcoes and opcoes.get('data_inicio') and opcoes.get('data_fim'):
                dt_ini = datetime.strptime(opcoes['data_inicio'], '%Y-%m-%d')
                dt_fim = datetime.strptime(opcoes['data_fim'], '%Y-%m-%d')
            else:
                # Se não colocar data, puxa o bloco dos últimos 7 dias fechados por padrão
                dt_fim = datetime.now() - timedelta(days=1)
                dt_ini = dt_fim - timedelta(days=7)

            print(f"⚙️ [PERFORMANCE] Iniciando análise consolidada para {conta['nome_conta']}...")
            
            # Passa apenas as datas inicial e final
            res = executar_analise_mercadolibre(user_id, conta, dt_ini, dt_fim)
            if isinstance(res, tuple): return {"sucesso": False, "mensagem": res[1]}
            
            if res.empty: return {"sucesso": True, "mensagem": "Nenhum dado encontrado."}

            df_novo = res.sort_values(by='Conversão %', ascending=True)
            
            client = get_gsheet_client({'GOOGLE_CREDENTIALS_FILE': 'credentials.json'})
            sheet_id = conta.get('spreadsheet_id') or SHEET_ID_PERFORMANCE
            sh = client.open_by_key(sheet_id)
            
            nome_aba_perf = f"PERF-{conta['nome_conta'].upper()}"[:30]
            
            try: ws = sh.worksheet(nome_aba_perf)
            except: ws = sh.add_worksheet(title=nome_aba_perf, rows=1000, cols=12)

            try: 
                header = ws.row_values(1)
                tem_header = len(header) > 0
            except: tem_header = False

            if not tem_header:
                ws.update([df_novo.columns.values.tolist()] + df_novo.values.tolist())
            else:
                ws.append_rows(df_novo.values.tolist())

            return {"sucesso": True, "mensagem": f"Performance atualizada na aba '{nome_aba_perf}'. ({len(df_novo)} registros consolidados)"}
            
    except Exception as e:
        traceback.print_exc()
        return {"sucesso": False, "mensagem": f"Erro crítico: {str(e)}"}

def gerar_relatorio_performance(user_id, plataforma='mercadolibre'):
    return gerar_relatorio_performance_v2(user_id, 'conversao')
