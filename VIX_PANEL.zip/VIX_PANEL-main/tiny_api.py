import os
import requests
import pandas as pd
import time
import threading
from datetime import datetime
from google_sheets import append_data_to_sheet, get_gsheet_client
from database import obter_conta

# ==========================================
# 👇 TOKENS DO TINY (PUXANDO DO RENDER / .ENV)
# ==========================================
TOKENS_TINY = {
    'Monaco Metais': os.environ.get('TINY_TOKEN_MONACO', ''), 
    'JSchruber': os.environ.get('TINY_TOKEN_JSCHRUBER', ''),
    'Gontarek': os.environ.get('TINY_TOKEN_GONTAREK', '')
}

# ==========================================
# 👇 REGRAS DE NEGÓCIO E ROTEAMENTO
# ==========================================
MAPA_EMPRESAS = {
    'amazon': 'Gontarek',
    'shopee': 'Monaco Metais',
    'shein': 'Monaco Metais',
    'tiktok': 'JSchruber',
    'temu': 'Gontarek' # TEMU NA GONTAREK
}

SPREADSHEET_MESTRA = '1lMq5aeInwwv7st8-Rf-S8NYQJaQKkSbSD7PjtFhtPms'

# ABA DA TEMU ATUALIZADA
MAPA_ABAS = {
    'amazon': 'VENDASAZ',
    'shopee': 'Shopee_Vendas',
    'shein': 'Shopee_Vendas',
    'tiktok': 'VENDASTK',
    'temu': 'VENDASTM' 
}

MAPA_ESTADOS = {
    'AC': 'Acre', 'AL': 'Alagoas', 'AP': 'Amapá', 'AM': 'Amazonas', 'BA': 'Bahia',
    'CE': 'Ceará', 'DF': 'Distrito Federal', 'ES': 'Espírito Santo', 'GO': 'Goiás',
    'MA': 'Maranhão', 'MT': 'Mato Grosso', 'MS': 'Mato Grosso do Sul', 'MG': 'Minas Gerais',
    'PA': 'Pará', 'PB': 'Paraíba', 'PR': 'Paraná', 'PE': 'Pernambuco', 'PI': 'Piauí',
    'RJ': 'Rio de Janeiro', 'RN': 'Rio Grande do Norte', 'RS': 'Rio Grande do Sul',
    'RO': 'Rondônia', 'RR': 'Roraima', 'SC': 'Santa Catarina', 'SP': 'São Paulo',
    'SE': 'Sergipe', 'TO': 'Tocantins'
}

def buscar_pedidos_tiny(token, d_ini, d_fim):
    """Busca a lista de IDs de pedidos no Tiny - DATA EXATA."""
    url_pesquisa = 'https://api.tiny.com.br/api2/pedidos.pesquisa.php'
    pedidos_encontrados = []
    pagina = 1
    
    dt_ini_tiny = datetime.strptime(d_ini, '%Y-%m-%d').strftime('%d/%m/%Y')
    dt_fim_tiny = datetime.strptime(d_fim, '%Y-%m-%d').strftime('%d/%m/%Y')

    while True:
        payload = {'token': token, 'formato': 'json', 'dataInicial': dt_ini_tiny, 'dataFinal': dt_fim_tiny, 'pagina': pagina}
        try:
            resp = requests.post(url_pesquisa, data=payload, timeout=10)
            if resp.status_code == 200:
                dados = resp.json()
                retorno = dados.get('retorno', {})
                if retorno.get('status') == 'Erro': break
                pedidos = retorno.get('pedidos', [])
                if not pedidos: break
                for p in pedidos: pedidos_encontrados.append(p['pedido']['id'])
                if pagina >= int(retorno.get('numero_paginas', 1)): break
                pagina += 1
                time.sleep(1) # Respeita a API já na paginação
            else: break
        except: break
    return pedidos_encontrados

def obter_detalhes_pedido_tiny(token, id_pedido, tentativa=1):
    """Busca os detalhes de 1 pedido, com extrema paciência anti-bloqueio."""
    url = 'https://api.tiny.com.br/api2/pedido.obter.php'
    try:
        resp = requests.post(url, data={'token': token, 'formato': 'json', 'id': id_pedido}, timeout=15)
        if resp.status_code == 200:
            retorno = resp.json().get('retorno', {})
            
            if retorno.get('status') == 'Erro': 
                if tentativa <= 5:
                    print(f"⚠️ [TINY API] Servidor negou o pedido {id_pedido}. Castigo de 5 segundos...")
                    time.sleep(5)
                    return obter_detalhes_pedido_tiny(token, id_pedido, tentativa + 1)
                return {}
                
            return retorno.get('pedido', {})
        else:
            if tentativa <= 5:
                time.sleep(5)
                return obter_detalhes_pedido_tiny(token, id_pedido, tentativa + 1)
    except:
        if tentativa <= 5:
            time.sleep(5)
            return obter_detalhes_pedido_tiny(token, id_pedido, tentativa + 1)
    return {}

# ==============================================================================
# A TAREFA DE FUNDO (Auditora e Lenta para Nunca Perder Dados)
# ==============================================================================
def _processar_tiny_background(user_id, google_creds_json, google_creds_file, d_ini, d_fim, plataforma, spreadsheet_id_override, sheet_name_override):
    try:
        print(f"\n⚙️ [BACKGROUND] Iniciando Modo Paciente para {plataforma.upper()}...")
        conta = obter_conta(user_id)
        if not conta: return
        
        spreadsheet_id = SPREADSHEET_MESTRA
        sheet_name = MAPA_ABAS.get(plataforma, 'Shopee_Vendas')
        nome_empresa_alvo = MAPA_EMPRESAS.get(plataforma)
        token_alvo = TOKENS_TINY.get(nome_empresa_alvo)

        if not token_alvo: return
        
        ids_pedidos = buscar_pedidos_tiny(token_alvo, d_ini, d_fim)
        if not ids_pedidos:
            print(f"✅ [BACKGROUND] Nenhum pedido para baixar da {plataforma.upper()}.")
            return

        print(f"🔍 [AUDITORIA] O Tiny informou que existem {len(ids_pedidos)} pedidos no total neste dia. Baixando calmamente...")

        pedidos_detalhados_brutos = []
        ids_pendentes = ids_pedidos.copy()
        tentativa_geral = 1
        
        while ids_pendentes and tentativa_geral <= 4:
            ids_falhos = []
            for pid in ids_pendentes:
                detalhe = obter_detalhes_pedido_tiny(token_alvo, pid)
                time.sleep(2) # ⬅️ O SEGREDO ESTÁ AQUI: 2 segundos de respiro entre CADA pedido
                
                if detalhe:
                    pedidos_detalhados_brutos.append(detalhe)
                else:
                    ids_falhos.append(pid)
                    
            ids_pendentes = ids_falhos
            if ids_pendentes:
                print(f"⚠️ [AUDITORIA] Falha ao baixar {len(ids_pendentes)} pedidos. Iniciando tentativa {tentativa_geral+1} em 5 segundos...")
                time.sleep(5)
            tentativa_geral += 1
            
        if ids_pendentes:
            print(f"❌ [AUDITORIA] Aviso Crítico: {len(ids_pendentes)} pedidos não puderam ser baixados do Tiny.")

        vendas_validas = []
        status_pagos = [
            'aprovado', 'preparando envio', 'faturado', 
            'pronto para envio', 'enviado', 'entregue', 
            'concluido', 'concluído'
        ]

        for pedido in pedidos_detalhados_brutos:
            numero = pedido.get('numero_ecommerce', pedido.get('numero', ''))
            ecommerce = str(pedido.get('ecommerce', '')).lower()
            origem = str(pedido.get('origem', '')).lower()
            
            if plataforma.lower() not in ecommerce and plataforma.lower() not in origem:
                continue 
                
            situacao = str(pedido.get('situacao', '')).strip().lower()
            
            if situacao not in status_pagos:
                print(f"🚫 [FILTRO] Pedido {numero} ({plataforma.upper()}) bloqueado! Motivo: Status no Tiny é '{situacao}'.")
                continue
                
            pedido['empresa_origem'] = nome_empresa_alvo
            vendas_validas.append(pedido)

        print(f"✅ [AUDITORIA] Processo concluído! Encontradas {len(vendas_validas)} vendas VÁLIDAS da {plataforma.upper()}. Formatando para a planilha...")

        if not vendas_validas:
            return
            
        linhas_finais = []
        for pedido in vendas_validas:
            data_pedido = pedido.get('data_pedido', d_ini)
            numero_pedido = pedido.get('numero_ecommerce', pedido.get('numero', ''))
            
            cliente = pedido.get('cliente', {})
            endereco_entrega = pedido.get('endereco_entrega', {})
            sigla_uf = (endereco_entrega.get('uf') or cliente.get('uf') or '').upper()
            estado_extenso = MAPA_ESTADOS.get(sigla_uf, sigla_uf)
            
            try:
                val_comissao = pedido.get('valor_comissao') or pedido.get('comissao_ecommerce') or pedido.get('ecommerce', {}).get('comissao') or 0.0
                comissao_api_bruta = float(val_comissao)
            except:
                comissao_api_bruta = 0.0
            
            itens = pedido.get('itens', [])
            primeiro_item = True 
            
            for item_wrapper in itens:
                item = item_wrapper.get('item', {})
                sku = item.get('codigo', 'SEM_SKU')
                
                try:
                    qtd = int(float(item.get('quantidade', 0)))
                    preco_unitario = float(item.get('valor_unitario', 0))
                except:
                    qtd = 1
                    preco_unitario = 0.0
                    
                total_item = preco_unitario * qtd
                comissao_linha = 0.00
                
                if comissao_api_bruta > 0:
                    if primeiro_item: comissao_linha = comissao_api_bruta
                else:
                    if plataforma == 'shopee': comissao_linha = (total_item * 0.235) + (4.00 * qtd)
                    elif plataforma == 'amazon': comissao_linha = (total_item * 0.11)
                    elif plataforma == 'shein': comissao_linha = (total_item * 0.16)
                    elif plataforma == 'tiktok': comissao_linha = (total_item * 0.05)
                    elif plataforma == 'temu': comissao_linha = (total_item * 0.18)
                    
                comissao_linha = abs(comissao_linha) * -1
                
                if plataforma == 'amazon':
                    linhas_finais.append([sku, sku, data_pedido, data_pedido, f"'{numero_pedido}", "Amazon", "", "Padrão", "", "FBM", round(preco_unitario, 2), qtd, round(total_item, 2), 0, 0, round(comissao_linha, 2), 0, conta['nome_conta'], estado_extenso])
                else:
                    linhas_finais.append([sku, sku, data_pedido, data_pedido, f"'{numero_pedido}", plataforma.capitalize(), "", "Padrão", "", "Padrão", f"{preco_unitario:.2f}".replace('.',','), qtd, f"{total_item:.2f}".replace('.',','), "0,00", "0,00", f"{comissao_linha:.2f}".replace('.',','), "0,00", conta['nome_conta'], estado_extenso])
                    
                primeiro_item = False
                    
        df = pd.DataFrame(linhas_finais)
        client = get_gsheet_client(config={'GOOGLE_CREDENTIALS_FILE': google_creds_file}) 
        sucesso = append_data_to_sheet(client, df, spreadsheet_id, sheet_name)

        if sucesso:
            print(f"🚀 [BACKGROUND] SUCESSO ABSOLUTO! {len(linhas_finais)} linhas inseridas na aba '{sheet_name}'.")
        else:
            print(f"❌ [BACKGROUND] Falha ao salvar os dados no Google Sheets.")
            
    except Exception as e:
        print(f"❌ [BACKGROUND] Erro Crítico: {e}")

# ==============================================================================
# FUNÇÃO PRINCIPAL (Libera a tela na hora)
# ==============================================================================
def executar_sincronizacao_tiny(user_id, google_creds_json, google_creds_file, d_ini, d_fim, plataforma, spreadsheet_id_override=None, sheet_name_override=None):
    thread = threading.Thread(
        target=_processar_tiny_background,
        args=(user_id, google_creds_json, google_creds_file, d_ini, d_fim, plataforma, spreadsheet_id_override, sheet_name_override)
    )
    thread.start()
    
    return {
        "sucesso": True, 
        "mensagem": f"A sincronização da {plataforma.upper()} começou em segundo plano! Acompanhe o Log do Servidor para ver a auditoria ao vivo."
    }
