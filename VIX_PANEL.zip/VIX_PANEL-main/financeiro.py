# financeiro.py (Versão ABAS SEPARADAS)
import pandas as pd
import requests
import concurrent.futures
import traceback
from datetime import datetime
from database import obter_conta, atualizar_conta
from google_sheets import get_gsheet_client

# --- CONFIGURAÇÃO ---
SHEET_ID_ESTOQUE = '1lMq5aeInwwv7st8-Rf-S8NYQJaQKkSbSD7PjtFhtPms' 

logs_execucao = []

def log(msg):
    timestamp = datetime.now().strftime("%H:%M:%S")
    mensagem = f"[{timestamp}] {msg}"
    print(mensagem)
    logs_execucao.append(mensagem)

def get_headers(token):
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

# ==============================================================================
#           AUTENTICAÇÃO
# ==============================================================================
def renovar_token_ml(client_id, client_secret, refresh_token):
    try:
        url = "https://api.mercadolibre.com/oauth/token"
        headers = {'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json'}
        data = {
            'grant_type': 'refresh_token', 'client_id': client_id, 
            'client_secret': client_secret, 'refresh_token': refresh_token
        }
        resp = requests.post(url, headers=headers, data=data, timeout=10)
        if resp.status_code == 200: return resp.json()
    except: pass
    return None

def get_valid_access_token(user_id):
    conta = obter_conta(user_id)
    if not conta: return None
    
    if conta.get('access_token'):
        try:
            r = requests.get("https://api.mercadolibre.com/users/me", headers={"Authorization": f"Bearer {conta['access_token']}"}, timeout=5)
            if r.status_code == 200: return conta['access_token']
        except: pass
            
    log(f"   🔄 Renovando token para {user_id}...")
    novos = renovar_token_ml(conta['client_id'], conta['client_secret'], conta['refresh_token'])
    if novos:
        atualizar_conta(user_id, {'access_token': novos['access_token'], 'refresh_token': novos['refresh_token']})
        return novos['access_token']
    return None

# ==============================================================================
#           MÓDULO DE BUSCA (ESTOQUE)
# ==============================================================================
def buscar_detalhe_inventario(inventory_id, token):
    if not inventory_id: return None
    try:
        url = f"https://api.mercadolibre.com/inventories/{inventory_id}/stock/fulfillment"
        r = requests.get(url, headers=get_headers(token), timeout=5)
        if r.status_code == 200: return r.json()
    except: pass
    return None

def buscar_itens_full(user_id, token):
    headers = get_headers(token)
    item_ids = []
    offset = 0; limit = 50
    
    log(f"   🔎 Buscando itens Full...")
    while True:
        url = f"https://api.mercadolibre.com/users/{user_id}/items/search?logistic_type=fulfillment&status=active&limit={limit}&offset={offset}"
        try:
            r = requests.get(url, headers=headers, timeout=10)
            if r.status_code != 200: break
            data = r.json(); results = data.get('results', [])
            if not results: break
            item_ids.extend(results)
            if len(results) < limit or len(item_ids) >= data.get('paging', {}).get('total', 0): break
            offset += limit
        except: break
    return item_ids

def obter_detalhes_estoque(item_ids, token, nome_conta, data_relatorio):
    headers = get_headers(token)
    linhas = []
    
    chunks = [item_ids[i:i + 20] for i in range(0, len(item_ids), 20)]
    log(f"   📦 Processando {len(item_ids)} itens...")

    def fetch_full_info(chunk):
        ids_str = ",".join(chunk)
        url = f"https://api.mercadolibre.com/items?ids={ids_str}" 
        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200: return r.json()
        except: pass
        return []

    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        results_basic = list(executor.map(fetch_full_info, chunks))

    mapa_mlb_invs = {}
    dados_mlb = {} 
    all_invs_to_check = [] 
    
    for batch in results_basic:
        if not batch: continue
        for item in batch:
            if item.get('code') == 200:
                body = item.get('body', {})
                mlb = body.get('id')
                
                dados_mlb[mlb] = {
                    'titulo': body.get('title', 'Sem título'),
                    'is_catalog': body.get('catalog_listing', False),
                    'fallback_qty': int(body.get('available_quantity', 0))
                }
                
                invs = []
                variations = body.get('variations', [])
                if variations:
                    for v in variations:
                        if v.get('inventory_id'): invs.append(v.get('inventory_id'))
                if not invs and body.get('inventory_id'):
                    invs.append(body.get('inventory_id'))
                
                if invs:
                    mapa_mlb_invs[mlb] = invs
                    all_invs_to_check.extend(invs)
    
    log(f"      -> Detalhando {len(all_invs_to_check)} inventários no Full...")

    mapa_detalhes = {} 
    if all_invs_to_check:
        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
            future_to_inv = {executor.submit(buscar_detalhe_inventario, inv, token): inv for inv in all_invs_to_check}
            
            for future in concurrent.futures.as_completed(future_to_inv):
                inv_id = future_to_inv[future]
                res = future.result()
                detalhe = {'disp': 0, 'descarte': 0, 'transf': 0, 'prazo': 0}
                if res:
                    detalhe['disp'] = int(res.get('available_quantity', 0))
                    if 'not_available_detail' in res:
                        for item_na in res['not_available_detail']:
                            status = item_na.get('status')
                            status_norm = status.lower() if status else ""
                            qtd = int(item_na.get('quantity', 0))
                            
                            if 'transfer' in status_norm:
                                detalhe['transf'] += qtd
                            elif status_norm in ['internalprocess', 'internal_process', 'withdrawal', 'quarantine']:
                                detalhe['prazo'] += qtd
                            elif status_norm in ['damaged', 'lost', 'disposed', 'nofiscalcoverage', 'not_supported']:
                                detalhe['descarte'] += qtd
                                
                mapa_detalhes[inv_id] = detalhe

    for mlb, info in dados_mlb.items():
        lista_invs = mapa_mlb_invs.get(mlb, [])
        t_disp = 0; t_descarte = 0; t_transf = 0; t_prazo = 0
        
        if lista_invs:
            for inv in lista_invs:
                d = mapa_detalhes.get(inv, {'disp': 0, 'descarte': 0, 'transf': 0, 'prazo': 0})
                t_disp += d['disp']; t_descarte += d['descarte']
                t_transf += d['transf']; t_prazo += d['prazo']
        else:
            t_disp = info['fallback_qty']
        
        mlb_display = mlb
        if info['is_catalog']: mlb_display = f"{mlb} (Catálogo)"

        linhas.append({
            'Data': data_relatorio,
            'Conta': nome_conta,
            'MLB do anúncio': mlb_display,
            'Total disponível': t_disp,
            'Total vendável': t_disp,
            'A Caminho (Inbound)': 0,
            'Total Descarte': t_descarte,
            'Total com prazo de estoque': t_prazo,
            'Total em transferencia': t_transf   
        })
                
    return linhas

# ==============================================================================
#           ROTEADOR PRINCIPAL (AGORA SALVA EM ABAS SEPARADAS)
# ==============================================================================
def processar_estoque_full(dados_formulario):
    global logs_execucao
    logs_execucao = [] 
    
    log("🚀 Iniciando (Modo Abas Separadas)...")

    try:
        data_input = dados_formulario.get('data_relatorio')
        if not data_input: data_relatorio = datetime.now().strftime('%d/%m/%Y')
        else:
            try: data_relatorio = datetime.strptime(data_input, '%Y-%m-%d').strftime('%d/%m/%Y')
            except: data_relatorio = datetime.now().strftime('%d/%m/%Y')

        contas_selecionadas = dados_formulario.getlist('contas')
        client = get_gsheet_client({'GOOGLE_CREDENTIALS_FILE': 'credentials.json'})
        
        # --- PROCESSAMENTO POR CONTA INDIVIDUAL ---
        for user_id in contas_selecionadas:
            try:
                log(f"--- Processando Conta ID: {user_id} ---")
                conta_info = obter_conta(user_id)
                if not conta_info: continue
                
                if conta_info.get('plataforma') and conta_info.get('plataforma') != 'mercadolibre': continue

                nome_conta = conta_info.get('nome_conta', user_id).upper()
                token = get_valid_access_token(user_id)
                if not token:
                    log("   ❌ Erro Token.")
                    continue

                ids = buscar_itens_full(user_id, token)
                if not ids:
                    log("   ⚠️ Sem itens Full.")
                    continue
                
                dados_conta = obter_detalhes_estoque(ids, token, nome_conta, data_relatorio)
                
                if dados_conta:
                    df_conta = pd.DataFrame(dados_conta)
                    
                    # Padroniza Colunas
                    cols_order = ['Data', 'Conta', 'MLB do anúncio', 'Total disponível', 'Total vendável', 'A Caminho (Inbound)', 'Total Descarte', 'Total com prazo de estoque', 'Total em transferencia']
                    for col in cols_order:
                        if col not in df_conta.columns: df_conta[col] = 0
                    df_conta = df_conta[cols_order].fillna(0)

                    # --- SALVAR NA ABA DA CONTA ---
                    sheet_id = conta_info.get('spreadsheet_id') or SHEET_ID_ESTOQUE
                    sh = client.open_by_key(sheet_id)
                    
                    # Nome da Aba: EF-ML-NOME (Max 30 chars)
                    nome_aba = f"EF-ML-{nome_conta}"[:30]
                    log(f"   💾 Salvando na aba: {nome_aba}")

                    try: ws = sh.worksheet(nome_aba)
                    except: ws = sh.add_worksheet(title=nome_aba, rows=1000, cols=10)
                    
                    ws.clear()
                    ws.update([df_conta.columns.values.tolist()] + df_conta.values.tolist())
                    
                    log(f"   ✅ Conta {nome_conta} finalizada com sucesso.")
                
            except Exception as e_conta:
                log(f"   ❌ Erro na conta {user_id}: {str(e_conta)}")
                print(traceback.format_exc())

        return {"sucesso": True, "mensagem": f"Processamento concluído.\nLOG:\n" + "\n".join(logs_execucao)}

    except Exception as e:
        traceback.print_exc()
        return {"sucesso": False, "mensagem": f"Erro Geral: {str(e)}\nLOG:\n" + "\n".join(logs_execucao)}
