import pandas as pd
import requests
import traceback
import time
from datetime import datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP

# --- IMPORTAÇÕES DE MÓDULOS LOCAIS ---
try:
    from database import obter_conta, atualizar_conta
    from google_sheets import get_gsheet_client, append_data_to_sheet
except ImportError as e:
    print(f"🔴 ERRO CRÍTICO no marketing.py: Falha ao importar módulos. {e}")
    def obter_conta(*args): return None
    def atualizar_conta(*args): return None
    def get_gsheet_client(*args): return None
    def append_data_to_sheet(*args): return False

# --- CONFIGURAÇÕES ---
SHEET_ID_MARKETING = '1lMq5aeInwwv7st8-Rf-S8NYQJaQKkSbSD7PjtFhtPms' 
NOME_ABA_PADRAO_ADS = 'ADS' 
NOME_ABA_RESUMO = 'ADS-TOTAL-ML' # <--- NOVA ABA DE RESUMO

# --- FUNÇÕES AUXILIARES ---
def safe_decimal(value):
    if pd.isna(value): return Decimal('0')
    if isinstance(value, Decimal): return value
    try:
        s_val = str(value).strip().replace('R$', '').replace(' ', '')
        if '.' in s_val and ',' in s_val: s_val = s_val.replace('.', '') 
        s_val = s_val.replace(',', '.')
        if s_val in ('', '-'): return Decimal('0')
        return Decimal(s_val)
    except: return Decimal('0')

def to_string_exact(value):
    if not isinstance(value, Decimal): value = safe_decimal(value)
    return str(value.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)).replace('.', ',')

def get_headers(token, api_version="2"):
    clean_token = str(token).strip()
    return {"Authorization": f"Bearer {clean_token}", "Content-Type": "application/json", "Api-Version": api_version}

# ==============================================================================
#           AUTENTICAÇÃO E RENOVAÇÃO
# ==============================================================================
def get_valid_access_token(user_id, force_refresh=False):
    conta = obter_conta(user_id)
    if not conta:
        raise Exception(f"Conta ML {user_id} não encontrada.")

    access_token = conta.get('access_token')
    
    if not force_refresh and access_token and access_token != 'inicial':
        return access_token 

    print(f"🔄 [MKT-AUTH] Renovando token para User ID {user_id}...")

    url = "https://api.mercadolibre.com/oauth/token"
    headers = {'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json'}
    
    payload = {
        'grant_type': 'refresh_token',
        'client_id': conta['client_id'],
        'client_secret': conta['client_secret'],
        'refresh_token': conta['refresh_token']
    }

    try:
        resp = requests.post(url, headers=headers, data=payload)
        resp.raise_for_status() 
        dados_auth = resp.json()

        novo_token = dados_auth['access_token']
        novo_refresh_token = dados_auth['refresh_token']

        atualizar_conta(user_id, {
            'access_token': novo_token,
            'refresh_token': novo_refresh_token
        })
        return novo_token
    
    except requests.exceptions.RequestException as e:
        print(f"❌ Erro fatal ao renovar token: {e}")
        raise Exception("Falha na renovação do token do Mercado Livre.")

# ==============================================================================
#                         LÓGICA DE BUSCA (DIA A DIA)
# ==============================================================================
def buscar_dados_ads_api(user_id, data_inicio, data_fim, tipo_ads='product_ads'):
    
    # 1. Configuração de Endpoint
    if tipo_ads == 'product_ads':
        ml_product_id = 'PADS'
        nome_aba = 'ADS'
        endpoint_type = 'ads' 
        metrics_list = "clicks,prints,cost,direct_amount,direct_items_quantity,total_amount"
        
    elif tipo_ads == 'brand_ads':
        ml_product_id = 'BADS'
        nome_aba = 'BRAND'
        endpoint_type = 'campaigns'
        metrics_list = "clicks,prints,consumed_budget,attribution_order_amount,attribution_order_conversions"
        
    elif tipo_ads == 'display_ads':
        ml_product_id = 'DISPLAY'
        nome_aba = 'DISPLAY'
        endpoint_type = 'campaigns'
        metrics_list = "clicks,prints,consumed_budget,attribution_order_amount,attribution_order_conversions"
    else:
        return {"sucesso": False, "mensagem": f"Tipo '{tipo_ads}' desconhecido."}

    try:
        # 2. Autenticação Inicial
        conta = obter_conta(user_id)
        if not conta: return {"sucesso": False, "mensagem": "Conta não encontrada."}
        
        token = get_valid_access_token(user_id)

        # 3. Identificar Anunciante (com Retry)
        def get_adv_request(t):
            return requests.get(
                'https://api.mercadolibre.com/advertising/advertisers', 
                params={'product_id': ml_product_id},
                headers=get_headers(t, "1")
            )

        resp_adv = get_adv_request(token)
        if resp_adv.status_code == 401:
            token = get_valid_access_token(user_id, force_refresh=True)
            resp_adv = get_adv_request(token)

        if resp_adv.status_code != 200:
            return {"sucesso": False, "mensagem": f"Erro ao acessar Advertiser: {resp_adv.text}"}

        advertisers_data = resp_adv.json().get('advertisers', [])
        if not advertisers_data:
             return {"sucesso": True, "mensagem": f"Nenhum anunciante ativo para {tipo_ads}."}
             
        adv_id = advertisers_data[0].get('advertiser_id')
        site_id = advertisers_data[0].get('site_id')

        print(f"--- [MKT] Extraindo dados de {tipo_ads} (Adv: {adv_id}) ---")

        # 3.1. MAPA DE NOMES DE CAMPANHAS
        mapa_campanhas = {}
        if endpoint_type == 'ads':
            try:
                url_map = f"https://api.mercadolibre.com/advertising/{site_id}/advertisers/{adv_id}/product_ads/campaigns/search?limit=100&status=active"
                r_map = requests.get(url_map, headers=get_headers(token, "2"))
                if r_map.status_code == 200:
                    for c in r_map.json().get('results', []):
                        mapa_campanhas[str(c['id'])] = c['name']
            except: pass 

        # ----------------------------------------------------------------------
        # 4. GERAÇÃO DA LISTA DE DIAS (LOOP DATA A DATA)
        # ----------------------------------------------------------------------
        dt_start = datetime.strptime(data_inicio, "%Y-%m-%d")
        dt_end = datetime.strptime(data_fim, "%Y-%m-%d")
        delta = dt_end - dt_start
        
        # Lista de datas strings YYYY-MM-DD
        dias_para_processar = []
        for i in range(delta.days + 1):
            dia = dt_start + timedelta(days=i)
            dias_para_processar.append(dia.strftime("%Y-%m-%d"))
            
        print(f"📅 Período selecionado: {data_inicio} a {data_fim}. Dias a processar: {len(dias_para_processar)}")

        linhas_totais = [] # Detalhado
        linhas_resumo = [] # Resumo Diário para ADS-TOTAL-ML
        
        timestamp = datetime.now().strftime('%d/%m/%Y %H:%M')
        nome_conta_upper = conta['nome_conta'].upper()
        nome_conta_formatado = f"Mercado Livre|{conta['nome_conta']}"

        # Loop Principal: Dia a Dia
        for dia_atual in dias_para_processar:
            print(f"   -> Processando dia {dia_atual}...")
            
            data_ref_br = datetime.strptime(dia_atual, '%Y-%m-%d').strftime('%d/%m/%Y')
            
            # Acumulador do dia para o relatório de totais
            total_investido_dia = Decimal(0)
            
            offset = 0
            limit = 50
            
            # Paginação dentro do dia
            while True:
                if endpoint_type == 'ads':
                    url = f"https://api.mercadolibre.com/advertising/{site_id}/advertisers/{adv_id}/{tipo_ads}/ads/search"
                    api_ver = "2"
                else:
                    url = f"https://api.mercadolibre.com/advertising/advertisers/{adv_id}/{tipo_ads}/campaigns"
                    api_ver = "1"

                params = {
                    'limit': limit,
                    'offset': offset,
                    'date_from': dia_atual,
                    'date_to': dia_atual,
                    'metrics': metrics_list,
                    'status': 'active' 
                }
                
                resp = requests.get(url, params=params, headers=get_headers(token, api_ver))
                
                if resp.status_code == 401:
                    token = get_valid_access_token(user_id, force_refresh=True)
                    resp = requests.get(url, params=params, headers=get_headers(token, api_ver))

                if resp.status_code != 200:
                    print(f"❌ Erro ao baixar dia {dia_atual}: {resp.text}")
                    break 

                payload = resp.json()
                items = payload.get('results') or payload.get('campaigns') or []
                
                if not items: break
                
                # Processa os itens desta página
                for item in items:
                    metrics = item.get('metrics', {})
                    camp_id = str(item.get('campaign_id') or item.get('id') or '-')
                    
                    if endpoint_type == 'ads':
                        id_anuncio = item.get('item_id', '-')   
                        titulo = item.get('title', '-')          
                        nome_campanha = mapa_campanhas.get(camp_id, f"Campanha {camp_id}")
                        custo = safe_decimal(metrics.get('cost', 0))
                        receita = safe_decimal(metrics.get('direct_amount', 0))
                        vendas_qtd = metrics.get('direct_items_quantity', 0)
                    else:
                        id_anuncio = "-" 
                        titulo = "-"
                        nome_campanha = item.get('name', f"Campanha {camp_id}")
                        custo = safe_decimal(metrics.get('consumed_budget', 0))
                        receita = safe_decimal(metrics.get('attribution_order_amount', 0))
                        vendas_qtd = metrics.get('attribution_order_conversions', 0)

                    # Soma para o relatório de Totais (Mesmo se for centavos)
                    total_investido_dia += custo

                    # Só adiciona no RELATÓRIO DETALHADO se teve custo ou clique
                    if custo > 0 or metrics.get('clicks', 0) > 0:
                        acos = (custo / receita * 100) if receita > 0 else Decimal(0)
                        roas = (receita / custo) if custo > 0 else Decimal(0)

                        linhas_totais.append({
                            'Tipo': tipo_ads,
                            'Data Ref': data_ref_br,
                            'Conta': nome_conta_formatado,
                            'Campanha': nome_campanha,
                            'ID Campanha': camp_id,
                            'ID Anúncio': id_anuncio,
                            'Título': titulo,
                            'Investimento': to_string_exact(custo),
                            'Receita': to_string_exact(receita),
                            'Vendas (Qtd)': vendas_qtd,
                            'ACOS': to_string_exact(acos),
                            'ROAS': to_string_exact(roas),
                            'Cliques': metrics.get('clicks', 0),
                            'Impressões': metrics.get('prints', 0),
                            'Ult. Atualização': timestamp
                        })

                # Verifica paginação
                total = payload.get('paging', {}).get('total', 0)
                if len(items) < limit or (offset + limit) >= total:
                    break
                offset += limit
                time.sleep(0.1) 
            
            # --- FINAL DO DIA: ADICIONA LINHA NO RESUMO ---
            # Adiciona apenas se teve algum gasto no dia, para não encher de zeros
            # (Ou remove o 'if' se quiser registrar dias zerados também)
            if total_investido_dia >= 0: 
                linhas_resumo.append({
                    'DIA': data_ref_br,
                    'CONTA': nome_conta_upper,
                    'VALOR': f"R$ {to_string_exact(total_investido_dia)}"
                })

            # Pausa estratégica entre dias
            time.sleep(1) 

        # 5. ENVIA TUDO PARA O SHEETS
        client = get_gsheet_client({'GOOGLE_CREDENTIALS_FILE': 'credentials.json'})
        sheet_id = conta.get('spreadsheet_id') or SHEET_ID_MARKETING

        msg_retorno = ""

        # A) SALVA O RELATÓRIO DETALHADO (ABA PADRÃO)
        if linhas_totais:
            df = pd.DataFrame(linhas_totais)
            colunas = ['Tipo', 'Data Ref', 'Conta', 'Campanha', 'ID Campanha', 'ID Anúncio', 'Título', 
                       'Investimento', 'Receita', 'Vendas (Qtd)', 'ACOS', 'ROAS', 'Cliques', 'Impressões', 'Ult. Atualização']
            
            for c in colunas:
                if c not in df.columns: df[c] = "-"
            
            df_final = df[colunas]
            append_data_to_sheet(client, df_final, sheet_id, nome_aba)
            msg_retorno += f"Detalhado: {len(linhas_totais)} linhas em '{nome_aba}'. "
        else:
            msg_retorno += "Detalhado: Sem dados. "

        # B) SALVA O RESUMO FINANCEIRO (NOVA ABA: ADS-TOTAL-ML)
        if linhas_resumo:
            df_resumo = pd.DataFrame(linhas_resumo)
            # Garante ordem das colunas
            df_resumo = df_resumo[['DIA', 'CONTA', 'VALOR']]
            
            append_data_to_sheet(client, df_resumo, sheet_id, NOME_ABA_RESUMO)
            msg_retorno += f"Resumo: {len(linhas_resumo)} dias em '{NOME_ABA_RESUMO}'."
        
        return {"sucesso": True, "mensagem": f"Sucesso! {msg_retorno}"}

    except Exception as e:
        print(f"Erro detalhado: {traceback.format_exc()}")
        return {"sucesso": False, "mensagem": f"Erro Interno: {str(e)}"}
