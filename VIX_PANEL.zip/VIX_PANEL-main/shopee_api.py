import os
import json
import requests
import traceback
import psycopg2
import psycopg2.extras 
import gspread
import time
import hmac
import hashlib
import urllib.parse
import pandas as pd
from datetime import datetime, timedelta
from google.oauth2.service_account import Credentials
import requests.exceptions

# Tenta importar o append inteligente
try:
    from google_sheets import append_data_to_sheet, get_gsheet_client
except ImportError:
    def append_data_to_sheet(*args, **kwargs): return True
    def get_gsheet_client(*args, **kwargs): return None

# --- MAPA DE ESTADOS ---
MAPA_ESTADOS = {
    'AC': 'Acre', 'AL': 'Alagoas', 'AP': 'Amapá', 'AM': 'Amazonas', 'BA': 'Bahia',
    'CE': 'Ceará', 'DF': 'Distrito Federal', 'ES': 'Espírito Santo', 'GO': 'Goiás',
    'MA': 'Maranhão', 'MT': 'Mato Grosso', 'MS': 'Mato Grosso do Sul', 'MG': 'Minas Gerais',
    'PA': 'Pará', 'PB': 'Paraíba', 'PR': 'Paraná', 'PE': 'Pernambuco', 'PI': 'Piauí',
    'RJ': 'Rio de Janeiro', 'RN': 'Rio Grande do Norte', 'RS': 'Rio Grande do Sul',
    'RO': 'Rondônia', 'RR': 'Roraima', 'SC': 'Santa Catarina', 'SP': 'São Paulo',
    'SE': 'Sergipe', 'TO': 'Tocantins'
}

def traduzir_estado(entrada):
    """Padroniza o estado. Retorna aviso se estiver mascarado."""
    if not entrada: return ""
    if "*" in entrada: return "Oculto pela Shopee" 
    
    entrada = str(entrada).strip().upper()
    entrada = entrada.replace("BR-", "") 
    
    if len(entrada) == 2:
        return MAPA_ESTADOS.get(entrada, entrada)
        
    for sigla, nome in MAPA_ESTADOS.items():
        if entrada == nome.upper():
            return nome
            
    return entrada.title()

# --- FUNÇÕES DE PERSISTÊNCIA (Movidas para isolamento) ---

DATABASE_URL = os.environ.get('DATABASE_URL') 
def get_db_connection():
    if not DATABASE_URL: raise Exception("Banco de Dados (PostgreSQL) não configurado.")
    return psycopg2.connect(DATABASE_URL)

def obter_conta(user_id):
    try:
        with get_db_connection() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                cursor.execute("SELECT * FROM accounts WHERE user_id = %s", (user_id,))
                row = cursor.fetchone()
                return dict(row) if row else None
    except: return None

def atualizar_conta(user_id, dados):
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                dados_update = {k: v for k, v in dados.items() if k != 'user_id'}
                campos = []
                valores = []
                for key, val in dados_update.items():
                    campos.append(f"{key} = %s")
                    valores.append(val)
                valores.append(datetime.now())
                valores.append(user_id)
                
                query = f"UPDATE accounts SET {', '.join(campos)}, updated_at = %s WHERE user_id = %s"
                cursor.execute(query, valores)
            conn.commit()
        return True, "Conta atualizada."
    except Exception as e:
        return False, str(e)

# --- CONFIGURAÇÕES SHOPEE ---

SHOPEE_HOST = "https://partner.shopeemobile.com" 
SH_ORDER_LIST_PATH = "/order/get_order_list"
SH_ORDER_DETAIL_PATH = "/order/get_order_detail"
SH_ABA_VENDAS = 'Shopee_Vendas'

# --- FUNÇÕES DE ASSINATURA ---

def get_shopee_signed_url(api_path, partner_id, partner_key, access_token, shop_id):
    base_url = SHOPEE_HOST + "/api/v2" 
    timest = int(time.time())
    
    partner_id_s = str(partner_id).strip() 
    shop_id_s = str(shop_id).strip() 
    access_token_s = str(access_token).strip()
    
    path_completo_para_base_string = "/api/v2" + api_path
    base_string = f"{partner_id_s}{path_completo_para_base_string}{timest}{access_token_s}{shop_id_s}"
    
    sign = hmac.new(
        partner_key.encode('utf-8'), 
        base_string.encode('utf-8'), 
        hashlib.sha256
    ).hexdigest()
    
    query_params = {
        'partner_id': partner_id_s,
        'timestamp': timest,
        'sign': sign,
        'access_token': access_token_s, 
        'shop_id': shop_id_s
    }
    return f"{base_url}{api_path}?{urllib.parse.urlencode(query_params)}"


def generate_public_sign(partner_id, partner_key, path, timestamp):
    partner_id_s = str(partner_id).strip() 
    base_string = f"{partner_id_s}{path}{timestamp}"
    return hmac.new(partner_key.encode('utf-8'), base_string.encode('utf-8'), hashlib.sha256).hexdigest()


# --- FUNÇÕES DE AUTENTICAÇÃO ---

def renovar_token_shopee(conta, partner_id, partner_key):
    shop_id = str(conta.get('user_id')).strip()
    refresh_token = str(conta.get('refresh_token')).strip()

    path_full = "/api/v2/auth/access_token/get"
    path_relative = "/auth/access_token/get"
    ts = int(time.time())

    sign = generate_public_sign(partner_id, partner_key, path_full, ts) 
    url = f"{SHOPEE_HOST}/api/v2{path_relative}?partner_id={partner_id}&timestamp={ts}&sign={sign}"
    
    data_payload = {
        "partner_id": int(partner_id), 
        "shop_id": int(shop_id), 
        "refresh_token": refresh_token
    }

    resp = requests.post(url, json=data_payload)
    if resp.status_code == 200 and not resp.json().get('error'): 
        return resp.json()
    else:
        raise Exception(f"Erro Shopee: {resp.text}")


def get_valid_shopee_token(user_id, partner_id, partner_key):
    conta = obter_conta(user_id)
    if not conta: raise Exception("Conta não encontrada.")
    try:
        novos = renovar_token_shopee(conta, partner_id, partner_key)
        atualizar_conta(user_id, {
            'access_token': novos['access_token'], 
            'refresh_token': novos['refresh_token']
        })
        print("--- [Shopee] Token renovado e salvo com sucesso. ---")
        return novos['access_token']
    except Exception as e:
        if conta.get('access_token') and conta.get('access_token') != 'inicial':
            print(f"--- [Shopee] Falha na renovação: {e}. Usando existente. ---")
            return conta.get('access_token')
        else:
            raise Exception(f"Falha crítica token: {e}")


# --- FUNÇÃO PRINCIPAL DE SINCRONIZAÇÃO (CORRIGIDA) ---

def executar_sincronizacao_shopee(user_id, google_creds_json, google_creds_file, data_inicio_custom=None, data_fim_custom=None, spreadsheet_id_override=None, sheet_name_override=None):
    
    # NOTA: Agora os argumentos são passados corretamente e usados.
    try:
        conta = obter_conta(user_id)
        if not conta: return {"sucesso": False, "mensagem": f"Conta {user_id} não encontrada."}
        
        partner_id = str(conta.get('client_id')).strip()
        partner_key = str(conta.get('client_secret')).strip()
        shop_id = str(conta.get('user_id')).strip() 
        
        # Determina o destino da planilha
        spreadsheet_id = spreadsheet_id_override or conta.get('spreadsheet_id')
        sheet_name = sheet_name_override or conta.get('sheet_name')
        if not spreadsheet_id: return {"sucesso": False, "mensagem": "ID da planilha não configurado."}
        
        nome_conta = str(conta.get('nome_conta')).strip()

        # 2. Tenta obter/renovar o Access Token
        try:
            access_token = get_valid_shopee_token(user_id, partner_id, partner_key)
        except Exception as e:
            return {"sucesso": False, "mensagem": f"Falha Token: {str(e)}"}
            
        # 3. Configuração de Datas
        data_inicio = datetime.strptime(data_inicio_custom, '%Y-%m-%d')
        data_fim = datetime.strptime(data_fim_custom, '%Y-%m-%d')
        
        time_from = int(data_inicio.timestamp())
        data_fim_margem = data_fim + timedelta(days=1, hours=4)
        time_to = int(data_fim_margem.timestamp())
        
        print(f"--- [Shopee] Buscando pedidos (Janela Estendida): {data_inicio_custom} a {data_fim_custom} ---")

        # 4. Buscar Lista de Pedidos (GET)
        order_list = []
        cursor = ""
        while True:
            payload_params = {
                "time_range_field": "create_time", 
                "time_from": time_from, 
                "time_to": time_to,
                "page_size": 100, 
                "cursor": cursor
            }
            url = get_shopee_signed_url(SH_ORDER_LIST_PATH, partner_id, partner_key, access_token, shop_id)
            full_url = url + "&" + urllib.parse.urlencode({k: v for k, v in payload_params.items() if v})

            resp = requests.get(full_url) 
            
            if resp.status_code != 200:
                return {"sucesso": False, "mensagem": f"Erro Lista {resp.status_code}: {resp.text}"}
            
            data = resp.json()
            if data.get('error'):
                return {"sucesso": False, "mensagem": f"Erro API Lista: {data.get('message')}"}
                
            if 'order_list' in data['response']:
                order_list.extend(data['response'].get('order_list', []))
            
            if data['response'].get('more'):
                cursor = data['response'].get('next_cursor')
            else:
                break
                
        if not order_list:
            return {"sucesso": True, "mensagem": f"Nenhum pedido encontrado em '{nome_conta}'."}
            
        print(f"--- [Shopee] {len(order_list)} pedidos encontrados. Buscando detalhes. ---")
        
        # 5. Buscar Detalhes (GET)
        order_sn_list = [order['order_sn'] for order in order_list]
        all_order_details = []
        batch_size = 50 
        
        for i in range(0, len(order_sn_list), batch_size):
            batch_sns = order_sn_list[i:i + batch_size]
            url_detail = get_shopee_signed_url(SH_ORDER_DETAIL_PATH, partner_id, partner_key, access_token, shop_id)
            
            params_detail = {
                "order_sn_list": ",".join(batch_sns),
                "response_optional_fields": "item_list,actual_shipping_fee,payment_info,recipient_address" 
            }
            full_url_detail = url_detail + "&" + urllib.parse.urlencode(params_detail)
            resp_detail = requests.get(full_url_detail)
            
            if resp_detail.status_code == 200:
                try:
                    data = resp_detail.json()
                    if not data.get('error'):
                        all_order_details.extend(data['response'].get('order_list', []))
                except: pass

        if not all_order_details:
             return {"sucesso": True, "mensagem": "Falha ao recuperar detalhes dos pedidos (Lista vazia)."}
             
        # 6. Processamento
        linhas_finais = []
        for order in all_order_details:
            order_sn = order['order_sn']
            create_time = datetime.fromtimestamp(order['create_time'])
            
            # --- Estado ---
            recipient = order.get("recipient_address", {})
            estado_raw = recipient.get("state")
            if not estado_raw: estado_raw = recipient.get("region")
            if not estado_raw: estado_raw = recipient.get("full_address") 
            estado_final = traduzir_estado(estado_raw)

            # --- Envio Seller (FIXO EM 0) ---
            shipping_cost = 0 

            # --- Taxas e Comissão (Regra Manual/Blindada) ---
            total_fees = 0.0
            
            payment_info = order.get("payment_info") or {}
            
            # 1. Tenta somar taxas da API
            fees_details = payment_info.get("seller_paid_fee_details")
            if fees_details:
                for fee in fees_details:
                    if fee.get("fee_type") in ["COMMISSION_FEE", "TRANSACTION_FEE", "SERVICE_FEE"]:
                        total_fees += float(fee.get("amount", 0))
            
            # 2. Se a API retornou 0, aplica a regra manual
            if total_fees == 0:
                total_order_amount = 0.0
                total_items_qty = 0
                for item in order.get("item_list", []):
                    price = float(item.get("model_original_price", item.get("item_original_price", 0)))
                    qty = int(item.get("model_quantity_purchased", 0))
                    total_order_amount += (price * qty)
                    total_items_qty += qty
                
                comissao_porcentagem = total_order_amount * 0.235
                taxa_fixa = 4.00 * total_items_qty
                total_fees = comissao_porcentagem + taxa_fixa
            
            total_fees = total_fees * -1 

            primeiro = True
            for item in order.get("item_list", []):
                sku = item.get("model_sku") or item.get("item_sku") or f"ITEM_{item.get('item_id')}"
                preco = float(item.get("model_original_price", item.get("item_original_price", 0)))
                qtd = int(item.get("model_quantity_purchased", 0))
                total_item = preco * qtd

                linha = [
                    sku,                                # SKU PRINCIPAL
                    sku,                                # SKU
                    data_inicio_custom,                 # Data da venda (USANDO D_INI da chamada)
                    data_inicio_custom,                 # EMISSAO
                    f"'{order_sn}",                     # N.º de venda
                    "Shopee",                           # origem
                    str(item.get("item_id")),           # # de anúncio
                    "Padrão",                           # tipo de anuncio
                    "",                                 # Venda por publicidade
                    "Shopee Xpress",                    # Forma de entrega
                    f"{preco:.2f}".replace('.',','),    # Preço unitário
                    qtd,                                # Unidades
                    f"{total_item:.2f}".replace('.',','), # Receita por produtos
                    "0,00",                             # Envio Seller
                    "0,00",                             # TARIFA
                    f"{total_fees:.2f}".replace('.',',') if primeiro else "0,00",    # COMISSÃO
                    "0,00",                             # ADS
                    nome_conta,                         # conta
                    estado_final                        # Estado
                ]
                linhas_finais.append(linha)
                primeiro = False

        # 7. Salvar
        df_shopee = pd.DataFrame(linhas_finais)
        cols = ['SKU PRINCIPAL', 'SKU', 'Data da venda', 'EMISSAO', 'N.º de venda', 'origem', '# de anúncio', 'tipo de anuncio', 'Venda por publicidade', 'Forma de entrega', 'Preço unitário de venda do anúncio (BRL)', 'Unidades', 'Receita por produtos (BRL)', 'Envio Seller', 'TARIFA', 'Tarifa de venda e impostos (BRL)', 'ADS', 'conta', 'Estado']
        df_shopee.columns = cols
        
        client = get_gsheet_client(config={'GOOGLE_CREDENTIALS_FILE': google_creds_file}) 
        sucesso = append_data_to_sheet(client, df_shopee, spreadsheet_id, sheet_name)
        
        if sucesso:
            return {"sucesso": True, "mensagem": f"Sucesso! {len(df_shopee)} linhas salvas em '{sheet_name}'."}
        else:
            return {"sucesso": False, "mensagem": "Erro ao salvar no Google Sheets."}
            
    except Exception as e:
        traceback.print_exc()
        return {"sucesso": False, "mensagem": f"Erro crítico: {str(e)}"}
