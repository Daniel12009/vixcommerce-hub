import os
import psycopg2
import psycopg2.extras
from datetime import datetime

DATABASE_URL = os.environ.get('DATABASE_URL') 

def get_db_connection():
    if not DATABASE_URL: raise Exception("Banco de Dados não configurado.")
    return psycopg2.connect(DATABASE_URL)

def init_db():
    if not DATABASE_URL: return
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS accounts (
                        id SERIAL PRIMARY KEY,
                        nome_conta TEXT NOT NULL,
                        user_id TEXT NOT NULL UNIQUE,
                        plataforma TEXT,
                        client_id TEXT,
                        client_secret TEXT,
                        access_token TEXT,
                        refresh_token TEXT,
                        spreadsheet_id TEXT,
                        sheet_name TEXT,
                        updated_at TIMESTAMP
                    )
                ''')
                # Garante que a coluna plataforma existe
                try:
                    cursor.execute("ALTER TABLE accounts ADD COLUMN plataforma TEXT;")
                    conn.commit()
                except psycopg2.errors.DuplicateColumn:
                    conn.rollback()
    except Exception as e:
        print(f"[DB] Erro init_db: {e}")

def obter_conta(user_id):
    try:
        with get_db_connection() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                cursor.execute("SELECT * FROM accounts WHERE user_id = %s", (user_id,))
                row = cursor.fetchone()
                return dict(row) if row else None
    except: return None

def salvar_conta(dados):
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute('''
                    INSERT INTO accounts (nome_conta, user_id, plataforma, client_id, client_secret, access_token, refresh_token, spreadsheet_id, sheet_name, updated_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ''', (
                    dados['nome_conta'], dados['user_id'], dados.get('plataforma', 'mercadolibre'),
                    dados['client_id'], dados['client_secret'],
                    dados.get('access_token', 'inicial'), dados['refresh_token'], 
                    dados.get('spreadsheet_id', ''), dados.get('sheet_name', ''),
                    datetime.now()
                ))
            conn.commit()
        return True, "Conta adicionada com sucesso!"
    except psycopg2.errors.UniqueViolation:
        return False, "Erro: Já existe uma conta com este ID."
    except Exception as e:
        return False, f"Erro ao salvar: {str(e)}"

def atualizar_conta(user_id, dados):
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                dados_update = {k: v for k, v in dados.items() if k != 'user_id'}
                campos = []
                valores = []
                for key, val in dados_update.items():
                    campos.append(f"{key} = %s")
                    valores.append(val)
                valores.append(datetime.now())
                valores.append(user_id)
                
                query = f"UPDATE accounts SET {', '.join(campos)}, updated_at = %s WHERE user_id = %s"
                cursor.execute(query, valores)
            conn.commit()
        return True, "Conta atualizada."
    except Exception as e:
        return False, str(e)

def listar_contas():
    try:
        with get_db_connection() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                cursor.execute("SELECT * FROM accounts ORDER BY nome_conta")
                return [dict(row) for row in cursor.fetchall()]
    except: return []

def excluir_conta(user_id):
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("DELETE FROM accounts WHERE user_id = %s", (user_id,))
            conn.commit()
        return True
    except: return False
