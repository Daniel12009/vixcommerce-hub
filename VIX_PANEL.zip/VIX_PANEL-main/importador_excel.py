# importador_excel.py (Versão Correção de Escrita A1 + Link de Verificação)
import pandas as pd
import traceback
import numpy as np
from datetime import datetime
from google_sheets import get_gsheet_client

# --- CONFIGURAÇÃO ---
SHEET_ID = '15a5rPb1TeMJCqcm4XzcpixCvtvi7RUFalMQxtNVkIH8' 
NOME_ABA = 'Full_Estoque'

def formatar_nome_conta(valor_select):
    mapa = {
        'viaflix': '(VIAFLIX)',
        'gs': '(GS)',
        'decarion': '(MONACO)'
    }
    return mapa.get(str(valor_select).lower(), f"({str(valor_select).upper()})")

def processar_upload_full(file_storage, conta_key):
    try:
        nome_conta_planilha = formatar_nome_conta(conta_key)
        print(f"📂 [IMPORT] Iniciando para: {nome_conta_planilha}")

        # 1. LER O EXCEL
        try:
            df = pd.read_excel(file_storage, header=None, engine='openpyxl')
        except Exception as e:
            return {"sucesso": False, "mensagem": f"Erro ao ler Excel: {str(e)}"}
        
        dados_extraidos = []
        data_hoje = datetime.now().strftime('%d/%m/%Y')

        # 2. VARRER LINHAS (PULA AS 3 PRIMEIRAS)
        for index, row in df.iterrows():
            try:
                if index < 3: continue

                # Pula linhas vazias ou cabeçalhos perdidos
                val_d = str(row.iloc[3]).strip()
                if val_d in ['', 'nan', 'SKU', 'sku', 'None']: continue

                # EXTRAÇÃO
                sku = val_d
                if sku.endswith('.0'): sku = sku[:-2]

                tamanho = str(row.iloc[7]).strip()
                if tamanho in ['nan', 'None', '']: tamanho = "-"

                status = str(row.iloc[9]).strip()
                if status in ['nan', 'None', '']: status = "-"

                def get_int(idx):
                    try:
                        val = row.iloc[idx]
                        if pd.isna(val) or str(val).strip() in ['-', '', 'nan', 'None']: return 0
                        return int(float(val))
                    except: return 0

                entrada_pendente = get_int(13)
                em_transferencia = get_int(14)
                devolvidas = get_int(15)
                aptas = get_int(16)
                ocupam_espaco = get_int(21)

                dados_extraidos.append({
                    'Data': data_hoje,
                    'Conta': nome_conta_planilha,
                    'SKU': sku,
                    'Tamanho': tamanho,
                    'Status do anúncio': status,
                    'Entrada pendente': entrada_pendente,
                    'Em transferência': em_transferencia,
                    'Devolvidas pelo comprador': devolvidas,
                    'Aptas para venda': aptas,
                    'Unidades que ocupan espacio en Full': ocupam_espaco
                })

            except Exception as e_row:
                continue

        print(f"   -> {len(dados_extraidos)} linhas preparadas na memória.")

        if not dados_extraidos:
            return {"sucesso": False, "mensagem": "Nenhum dado encontrado a partir da 4ª linha."}

        df_novo = pd.DataFrame(dados_extraidos)

        # 3. CONECTAR AO GOOGLE SHEETS
        client = get_gsheet_client({'GOOGLE_CREDENTIALS_FILE': 'credentials.json'})
        try:
            sh = client.open_by_key(SHEET_ID)
            ws = sh.worksheet(NOME_ABA)
            
            # IMPRIME O LINK PARA VOCÊ CONFERIR SE É A PLANILHA CERTA
            print(f"   🔗 CONECTADO NA PLANILHA: https://docs.google.com/spreadsheets/d/{SHEET_ID}")
            print(f"   📑 ABA ALVO: {NOME_ABA}")
            
        except Exception as e:
             return {"sucesso": False, "mensagem": f"Erro ao acessar planilha/aba. Verifique ID e Nome da Aba. Erro: {e}"}
        
        # Baixa dados antigos
        try:
            dados_existentes = ws.get_all_records()
            df_antigo = pd.DataFrame(dados_existentes)
        except:
            df_antigo = pd.DataFrame()

        # Filtra (Remove a conta atual)
        if not df_antigo.empty and 'Conta' in df_antigo.columns:
            df_final = df_antigo[df_antigo['Conta'] != nome_conta_planilha]
        else:
            df_final = pd.DataFrame()

        # Junta
        df_final = pd.concat([df_final, df_novo], ignore_index=True)

        # Organiza
        cols_order = [
            'Data', 'Conta', 'SKU', 'Tamanho', 'Status do anúncio', 
            'Entrada pendente', 'Em transferência', 'Devolvidas pelo comprador', 
            'Aptas para venda', 'Unidades que ocupan espacio en Full'
        ]
        
        for c in cols_order:
            if c not in df_final.columns: df_final[c] = 0 
            
        df_final = df_final[cols_order]

        # Sanitiza (NaN -> 0)
        df_final = df_final.fillna(0)
        df_final = df_final.replace([np.inf, -np.inf], 0)
        
        # Converte para lista
        dados_finais = [df_final.columns.values.tolist()] + df_final.values.tolist()

        # 4. SALVAR (COMANDO CORRIGIDO)
        print(f"   -> Limpando aba e escrevendo {len(dados_finais)} linhas...")
        ws.clear()
        
        # AQUI ESTÁ A CORREÇÃO PRINCIPAL: Adicionei 'A1' para forçar o início
        try:
            ws.update('A1', dados_finais) 
        except:
            # Tenta sem o A1 caso a biblioteca seja muito antiga (fallback)
            ws.update(dados_finais)

        return {"sucesso": True, "mensagem": f"Sucesso! {len(dados_extraidos)} linhas enviadas para a aba {NOME_ABA}."}

    except Exception as e:
        print(f"❌ ERRO CRÍTICO: {traceback.format_exc()}")
        return {"sucesso": False, "mensagem": f"Erro Crítico: {str(e)}"}
