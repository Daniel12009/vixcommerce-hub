import os
import traceback
import threading
import time
import json
import re
from collections import deque
from datetime import datetime, timedelta, date

# Bibliotecas de Processamento de Dados
import pandas as pd

# Flask e Utilitários Web
from flask import Flask, render_template, request, flash, redirect, url_for, send_file, jsonify
from dotenv import load_dotenv

# Módulo de Upload (Seu arquivo importador_excel.py)
try:
    from importador_excel import processar_upload_full
except ImportError:
    # Fallback caso o arquivo não exista localmente
    def processar_upload_full(file, conta):
        return {"sucesso": False, "mensagem": "Módulo importador_excel.py não encontrado."}

# --- NOVO: Importação dos Agentes de IA ---
print(f"Arquivos no diretório: {os.listdir('.')}")
try:
    from agentes_ia import iniciar_orquestrador
    print("✅ Módulo agentes_ia carregado com sucesso!")
except Exception as e:
    print(f"❌ Erro Real na Importação de agentes_ia: {str(e)}")
    traceback.print_exc() # Isso vai imprimir a linha exata do erro no log
    def iniciar_orquestrador(): pass
    def agente_analista_ads(): pass

# ==============================================================================
#                  CONFIGURAÇÃO INICIAL DO SERVIDOR
# ==============================================================================

# Define o diretório base do projeto
basedir = os.path.abspath(os.path.dirname(__file__))

# Carrega as variáveis do arquivo .env (Senhas, Tokens)
load_dotenv(os.path.join(basedir, '.env'))

# Inicializa o App Flask
app = Flask(__name__)

# Configurações de Segurança e Upload
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or 'chave_secreta_padrao_desenvolvimento'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024 * 5  # Limite de 80MB (5 * 16MB chunks)
app.config['GOOGLE_CREDENTIALS_FILE'] = os.environ.get('GOOGLE_CREDENTIALS_FILE') or 'credentials.json'

# ==============================================================================
#                  CONFIGURAÇÃO DAS PLANILHAS (DASHBOARD)
# ==============================================================================

# ID da Planilha Mestra (Google Sheets)
SHEET_ID = '1lMq5aeInwwv7st8-Rf-S8NYQJaQKkSbSD7PjtFhtPms'

# 1. ABA VENDAS (Dados Históricos do ERP)
GID_VENDAS = '617109756' 

# 2. ABA ADS (Aba Nova: ADS-TOTAL) - GID Verificado
GID_ADS = '564697924' 

# Função Auxiliar: Gera URL do CSV com Timestamp para evitar Cache
def get_csv_url(gid):
    """
    Retorna a URL de exportação CSV do Google Sheets.
    Adiciona o parâmetro &t=TIMESTAMP para forçar o Google a entregar dados novos.
    """
    timestamp = int(time.time())
    base_url = f'https://docs.google.com/spreadsheets/d/{SHEET_ID}/export?format=csv&gid={gid}'
    return f"{base_url}&t={timestamp}"

# ==============================================================================
#                  SISTEMA DE LOGS (MONITORAMENTO)
# ==============================================================================

# Fila de logs em memória (guarda os últimos 50 eventos)
SYSTEM_LOGS = deque(maxlen=50)

def add_log(tipo, mensagem):
    """Adiciona uma mensagem ao log do sistema visível no painel."""
    hora_atual = datetime.now().strftime('%H:%M:%S')
    # Limita o tamanho da mensagem para não quebrar o layout
    msg_limpa = str(mensagem).split('\n')[0][:200]
    
    entry = {
        "hora": hora_atual,
        "tipo": tipo,  # 'info', 'error', 'success'
        "mensagem": msg_limpa
    }
    SYSTEM_LOGS.appendleft(entry)
    # Também imprime no console do servidor para debug
    print(f"[{tipo.upper()}] {msg_limpa}")

# ==============================================================================
#                  IMPORTAÇÃO DE MÓDULOS DE NEGÓCIO
# ==============================================================================

# 1. BANCO DE DADOS E FICHAS TÉCNICAS
try:
    from database import listar_contas, salvar_conta, excluir_conta, atualizar_conta, obter_conta, init_db
    
    try: 
        from fichas_tecnicas import (
            init_db as init_fichas, 
            buscar_produto_db, 
            obter_dados_por_sku, 
            salvar_ficha_db, 
            excluir_produto_db, 
            gerar_excel_marketplace
        )
    except ImportError: 
        print("⚠️ Módulo Fichas Técnicas não carregado completamente.")
        def init_fichas(): pass
        def buscar_produto_db(*args): return None
        def obter_dados_por_sku(*args): return None
        def salvar_ficha_db(*args): return False, "Módulo Fichas ausente"
        def excluir_produto_db(*args): return False
        def gerar_excel_marketplace(*args): return None, None

    # Inicializa os Bancos de Dados SQLite ao iniciar o servidor
    with app.app_context():
        try:
            init_db()
            print("✅ Banco de Dados (Contas) Verificado.")
            init_fichas()
            print("✅ Banco de Dados (Fichas) Verificado.")
        except Exception as e:
            print(f"❌ Erro ao inicializar Bancos de Dados: {e}")

except ImportError as e:
    print(f"❌ Erro Crítico: Módulo 'database.py' não encontrado: {e}")
    # Mockups para o servidor não cair
    def listar_contas(): return []
    def obter_conta(u): return None
    def salvar_conta(d): return False, "Erro DB"
    def excluir_conta(u): return False
    def atualizar_conta(u, d): return False, "Erro DB"

# 2. MÓDULO DE VENDAS (Integração Google Sheets)
try: 
    from VendasGS import processar_envio_vendas
except ImportError: 
    print("⚠️ Módulo VendasGS não encontrado.")
    def processar_envio_vendas(*args, **kwargs): 
        return {"sucesso": False, "mensagem": "Módulo VendasGS não instalado."}

# 3. MÓDULO DE PERFORMANCE (Relatórios ML)
try:
    from performance import gerar_relatorio_performance_v2
except ImportError:
    print("⚠️ Módulo Performance não encontrado.")
    def gerar_relatorio_performance_v2(*args): 
        return {"sucesso": False, "mensagem": "Módulo Performance não instalado."}

# 4. MÓDULO DE MARKETING (API ADS)
try: 
    from marketing import buscar_dados_ads_api
except ImportError: 
    print("⚠️ Módulo Marketing não encontrado.")
    def buscar_dados_ads_api(*args): 
        return {"sucesso": False, "mensagem": "Módulo Marketing não instalado."}

# 5. MÓDULO FINANCEIRO (Estoque Tiny/Bling)
try: 
    from financeiro import processar_estoque_full 
except ImportError: 
    print("⚠️ Módulo Financeiro não encontrado.")
    def processar_estoque_full(*args): 
        return {"sucesso": False, "mensagem": "Módulo Financeiro não instalado."}

# --- FUNÇÃO WRAPPER PARA BACKGROUND TASKS (THREADS) ---
def background_task(func, args):
    """
    Executa uma função em segundo plano para não travar a requisição HTTP.
    Captura exceções e loga no sistema.
    """
    with app.app_context():
        try:
            func(*args)
        except Exception as e:
            traceback.print_exc()
            add_log("error", f"Erro na Tarefa de Fundo: {str(e)}")

# ==============================================================================
#                  FUNÇÕES DE LEITURA E TRATAMENTO DE DADOS
# ==============================================================================

def limpar_moeda_br(valor):
    """
    Converte strings de moeda (R$ 1.200,50) para float (1200.50).
    Trata erros comuns de formatação.
    """
    if pd.isna(valor) or str(valor).strip() == '':
        return 0.0
    
    # Remove caracteres não numéricos básicos
    s = str(valor).strip().upper()
    s = s.replace('R$', '').replace('%', '').replace(' ', '')
    
    # Verifica erros de planilha
    if 'DIV' in s or 'N/A' in s or 'REF' in s:
        return 0.0
    
    try:
        # Lógica para formato brasileiro (1.000,00)
        if '.' in s and ',' in s:
            # Remove o ponto de milhar e troca vírgula por ponto
            return float(s.replace('.', '').replace(',', '.'))
        
        # Lógica para decimal simples com vírgula (50,00)
        if ',' in s:
            return float(s.replace(',', '.'))
            
        # Lógica para número puro (1000)
        return float(s)
    except ValueError:
        return 0.0

def carregar_vendas_principal():
    """
    Lê a aba de VENDAS do Google Sheets.
    Aplica limpeza nas colunas numéricas e de data.
    """
    try:
        url = get_csv_url(GID_VENDAS)
        print(f"📥 Baixando VENDAS de: {url}")
        
        df = pd.read_csv(url)
        # Remove espaços em branco dos cabeçalhos
        df.columns = df.columns.str.strip()
        
        # Converte colunas de dinheiro
        cols_moeda = ['ValorPedido', 'Líquido Custo Real', 'quantidade']
        for col in cols_moeda:
            if col in df.columns:
                df[col] = df[col].apply(limpar_moeda_br)
            
        # Converte coluna de Data
        if 'dataAprovacao' in df.columns:
            df['dataAprovacao'] = pd.to_datetime(df['dataAprovacao'], dayfirst=True, errors='coerce')
        
        # Normaliza textos para facilitar filtros (tudo minúsculo)
        if 'Conta' in df.columns:
            df['conta_lower'] = df['Conta'].astype(str).str.lower()
        if 'pedidoOrigem' in df.columns:
            df['canal_lower'] = df['pedidoOrigem'].astype(str).str.lower()
            
        return df
    except Exception as e:
        print(f"❌ Erro ao carregar Vendas: {e}")
        return pd.DataFrame()

def carregar_ads_custo():
    """
    Lê a aba de ADS (Nova Estrutura: MKT e CONTA).
    Esta função é crítica para o Dashboard.
    """
    try:
        url = get_csv_url(GID_ADS)
        print(f"📥 Baixando ADS de: {url}")
        
        df = pd.read_csv(url)
        # Padroniza colunas para maiúsculo para facilitar a busca
        df.columns = df.columns.str.strip().str.upper() 
        
        # --- 1. LOCALIZAR AS COLUNAS CORRETAS ---
        col_data = None
        col_valor = None
        col_mkt = None
        col_conta = None
        
        for col in df.columns:
            if 'DATA' in col: col_data = col 
            elif col in ['ADS', 'VALOR', 'CUSTO']: col_valor = col
            elif col in ['MKT', 'MARKETPLACE']: col_mkt = col
            elif col in ['CONTA']: col_conta = col
            
        if not col_data or not col_valor:
            print(f"🚨 ERRO ADS: Colunas Data/Valor não encontradas. Colunas atuais: {df.columns.tolist()}")
            return pd.DataFrame()

        # --- 2. SELEÇÃO DE COLUNAS ---
        cols_para_usar = [col_data, col_valor]
        if col_mkt: cols_para_usar.append(col_mkt)
        if col_conta: cols_para_usar.append(col_conta)
        
        df = df[cols_para_usar].copy()
        
        # Remove linhas onde o valor ou a data estão vazios
        df.dropna(subset=[col_data], inplace=True)
        
        # --- 3. CONVERSÃO DE DADOS ---
        df['DATA'] = pd.to_datetime(df[col_data], dayfirst=True, errors='coerce')
        df['CUSTO'] = df[col_valor].fillna(0).apply(limpar_moeda_br)
        
        # Remove datas inválidas que falharam na conversão
        df = df.dropna(subset=['DATA'])

        # --- 4. NORMALIZAÇÃO DE NOMES (Marketplace e Conta) ---
        def normalizar_row(row):
            # Pega o valor original da célula com segurança
            txt_mkt = str(row[col_mkt]).lower() if col_mkt and pd.notna(row[col_mkt]) else ""
            txt_conta = str(row[col_conta]).lower() if col_conta and pd.notna(row[col_conta]) else ""
            
            # Lógica de Identificação do Canal
            canal = 'outros'
            if 'mercado' in txt_mkt: canal = 'mercado'
            elif 'shopee' in txt_mkt: canal = 'shopee'
            elif 'amazon' in txt_mkt: canal = 'amazon'
            elif 'shein' in txt_mkt: canal = 'shein'
            elif 'tiktok' in txt_mkt: canal = 'tiktok'
            
            # Lógica de Identificação da Conta
            conta = 'geral'
            # Concatena para buscar em ambos os campos
            txt_full = txt_mkt + " " + txt_conta
            
            if 'via' in txt_full or 'flix' in txt_full or 'fix' in txt_full: conta = 'viaflix'
            elif 'decarion' in txt_full: conta = 'decarion'
            elif 'gs' in txt_full or 'torneiras' in txt_full: conta = 'gstorneiras'
            
            return pd.Series([canal, conta])

        # Aplica a normalização linha a linha
        df[['canal_lower', 'conta_lower']] = df.apply(normalizar_row, axis=1)
        
        print(f"✅ ADS Carregado. Total: R$ {df['CUSTO'].sum():.2f}")
        return df

    except Exception as e:
        print(f"❌ Erro Crítico no ADS: {e}")
        traceback.print_exc()
        return pd.DataFrame()

# ==============================================================================
#                        ROTA PRINCIPAL: DASHBOARD
# ==============================================================================

@app.route('/dashboard')
def dashboard():
    # 1. Carrega os Dados
    df_v = carregar_vendas_principal()
    df_a = carregar_ads_custo()
    
    # 2. Pega Filtros da URL
    periodo = request.args.get('periodo', '30d')
    conta = request.args.get('conta', 'all').lower()
    mkt = request.args.get('marketplace', 'all').lower()
    tipo = request.args.get('tipo_canal', 'todos')
    
    hoje = pd.Timestamp.now().normalize()
    
    # --- 3. CÁLCULO DE PERFORMANCE 7 DIAS (FIXO) ---
    # Estes dados aparecem no card lateral independentemente do filtro principal
    vendas_7d = 0.0
    ads_7d = 0.0
    roas_7d = 0.0
    
    try:
        data_limite_7d = hoje - timedelta(days=7)
        
        # Cálculo Vendas 7D
        if not df_v.empty:
            df_v7 = df_v[df_v['dataAprovacao'] >= data_limite_7d]
            # Aplica filtros de conta/mkt para manter coerência com o usuário
            if conta != 'all': 
                termo_conta = 'via flix' if conta == 'viaflix' else 'gs' if conta == 'gstorneiras' else 'decarion'
                df_v7 = df_v7[df_v7['conta_lower'].str.contains(termo_conta, na=False)]
            if mkt != 'all': 
                df_v7 = df_v7[df_v7['canal_lower'].str.contains(mkt, na=False)]
            vendas_7d = df_v7['ValorPedido'].sum()
            
        # Cálculo Ads 7D
        if not df_a.empty:
            df_a7 = df_a[df_a['DATA'] >= data_limite_7d]
            if conta != 'all': 
                df_a7 = df_a7[df_a7['conta_lower'] == conta]
            if mkt != 'all': 
                termo_mkt_7d = 'mercado' if 'mercado' in mkt else mkt
                df_a7 = df_a7[df_a7['canal_lower'].str.contains(termo_mkt_7d, na=False)]
            ads_7d = df_a7['CUSTO'].sum()
            
        # Cálculo ROAS 7D
        if ads_7d > 0:
            roas_7d = vendas_7d / ads_7d
            
    except Exception as e:
        print(f"Erro ao calcular KPI 7 dias: {e}")

    # --- 4. FILTRAGEM DE DADOS (PRINCIPAL) ---
    
    def aplicar_filtro_data(df, coluna_data):
        """Aplica o filtro de tempo selecionado pelo usuário"""
        if periodo == 'hoje':
            return df[df[coluna_data] >= hoje]
        elif periodo == '7d':
            return df[df[coluna_data] >= (hoje - pd.Timedelta(days=7))]
        elif periodo == '15d':
            return df[df[coluna_data] >= (hoje - pd.Timedelta(days=15))]
        elif periodo == '30d':
            return df[df[coluna_data] >= (hoje - pd.Timedelta(days=30))]
        return df # Retorna tudo se não tiver filtro

    # Filtra VENDAS
    if not df_v.empty:
        df_v = aplicar_filtro_data(df_v, 'dataAprovacao')
        
        if conta != 'all': 
            termo_conta = 'via flix' if conta == 'viaflix' else 'gs' if conta == 'gstorneiras' else 'decarion'
            df_v = df_v[df_v['conta_lower'].str.contains(termo_conta, na=False)]
            
        if tipo == 'mkt': 
            df_v = df_v[~df_v['canal_lower'].str.contains('atacado|loja|balcao', na=False)]
        elif tipo == 'fisico': 
            df_v = df_v[df_v['canal_lower'].str.contains('atacado|loja|balcao', na=False)]
            
        if mkt != 'all': 
            df_v = df_v[df_v['canal_lower'].str.contains(mkt, na=False)]

    # Filtra ADS
    if tipo != 'fisico' and not df_a.empty:
        df_a = aplicar_filtro_data(df_a, 'DATA')
        
        if conta != 'all': 
            df_a = df_a[df_a['conta_lower'] == conta]
            
        if mkt != 'all': 
            termo_mkt = 'mercado' if 'mercado' in mkt else mkt
            df_a = df_a[df_a['canal_lower'].str.contains(termo_mkt, na=False)]
    else:
        # Se for venda física, zera o Ads
        df_a = pd.DataFrame()

    # --- 5. CÁLCULO DE KPIS FINAIS ---
    
    fat = df_v['ValorPedido'].sum() if not df_v.empty else 0
    luc = df_v['Líquido Custo Real'].sum() if not df_v.empty else 0
    ads = df_a['CUSTO'].sum() if not df_a.empty else 0
    ped = df_v['quantidade'].count() if not df_v.empty else 0
    
    margem_real = luc - ads
    roas = (fat / ads) if ads > 0 else 0
    margem_perc = (margem_real / fat * 100) if fat > 0 else 0

    # Formatador de Moeda Visual
    def fmt(v): 
        return f"R$ {v:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')

    kpis = {
        'faturamento': fmt(fat),
        'lucro': fmt(luc),
        'ads': fmt(ads),
        'margem_real_val': fmt(margem_real),
        'margem_perc': f"{margem_perc:.1f}%",
        'roas': f"{roas:.2f}".replace('.',','),
        'qtd': int(ped),
        # Adiciona KPIs de 7 dias calculados no passo 3
        'vendas_7d': fmt(vendas_7d),
        'ads_7d': fmt(ads_7d),
        'roas_7d': f"{roas_7d:.2f}".replace('.',',')
    }

    # --- 6. GERAÇÃO DE GRÁFICOS ---
    
    graficos = {
        'vendas_dia': {'labels': [], 'data': []}, 
        'roas_dia': {'data': []}, 
        'mkt_share': {'labels': [], 'data': []}, 
        'top_skus_fat': [], 
        'top_skus_luc': [], 
        'estados': {'labels': [], 'data': []}
    }

    if not df_v.empty:
        # Gráfico Diário
        diario = df_v.groupby('dataAprovacao')['ValorPedido'].sum().sort_index()
        graficos['vendas_dia']['labels'] = [d.strftime('%d/%m') for d in diario.index]
        graficos['vendas_dia']['data'] = diario.values.tolist()
        
        # Share de Marketplace
        if 'pedidoOrigem' in df_v.columns:
            share = df_v.groupby('pedidoOrigem')['ValorPedido'].sum().sort_values(ascending=False).head(5)
            graficos['mkt_share'] = {'labels': share.index.tolist(), 'data': share.values.tolist()}
        
        # Top SKUs (Faturamento e Lucro)
        if 'SkuProduto' in df_v.columns:
            top = df_v.groupby('SkuProduto')['ValorPedido'].sum().sort_values(ascending=False).head(5)
            graficos['top_skus_fat'] = [{'sku': k, 'val': v} for k,v in top.items()]
            
            topl = df_v.groupby('SkuProduto')['Líquido Custo Real'].sum().sort_values(ascending=False).head(5)
            graficos['top_skus_luc'] = [{'sku': k, 'val': v} for k,v in topl.items()]
            
        # Mapa de Calor (Estados)
        if 'Estado' in df_v.columns:
            est = df_v.groupby('Estado')['ValorPedido'].sum().sort_values(ascending=False).head(5)
            graficos['estados'] = {'labels': est.index.tolist(), 'data': est.values.tolist()}

    # Gráfico ROAS Diário
    if not df_a.empty and not df_v.empty:
        try:
            ads_dia = df_a.groupby('DATA')['CUSTO'].sum()
            # Alinha as datas do Ads com as datas das Vendas (preenche com 0 se faltar)
            ads_align = ads_dia.reindex(diario.index, fill_value=0)
            
            # Calcula ROAS (Vendas / Ads) protegendo divisão por zero
            r = (diario / ads_align).replace([float('inf'), -float('inf')], 0).fillna(0)
            graficos['roas_dia']['data'] = [round(x,2) for x in r.values.tolist()]
        except Exception as e:
            print(f"Erro grafico ROAS: {e}")

    # Retorna o template renderizado
    return render_template('dashboard.html', dados=kpis, graficos=graficos, filtros={'periodo': periodo, 'conta': conta, 'mkt': mkt, 'tipo_canal': tipo})

# ==============================================================================
#                  ROTAS DE NAVEGAÇÃO (MENUS LATERAIS)
# ==============================================================================

@app.route('/')
def selection_page(): 
    """Página inicial de seleção de módulos"""
    return render_template('selection.html')

@app.route('/contas')
def accounts_page(): 
    """Página de Gerenciamento de Contas"""
    return render_template('accounts.html')

@app.route('/vendas')
def vendas_page(): 
    """Página de Envio de Vendas para Planilha"""
    return render_template('vendas_view.html')

@app.route('/performance')
def performance_page(): 
    """Página de Performance e Conversão"""
    return render_template('performance.html')

@app.route('/financeiro')
def financeiro_page():
    """Página do Financeiro (Processamento de Estoque)"""
    contas = listar_contas()
    # Filtra apenas contas do ML para financeiro
    contas_ml = [c for c in contas if c.get('plataforma', 'mercadolibre') == 'mercadolibre']
    return render_template('financeiro.html', contas=contas_ml)

@app.route('/marketing')
def marketing_page(): 
    """Página de Marketing (Em desenvolvimento)"""
    return render_template('marketing_view.html')

@app.route('/estoque')
def estoque(): 
    """Página de Estoque Geral"""
    return render_template('estoque.html')

@app.route('/ads')
def ads(): 
    """Página de Gerenciamento de Ads"""
    return render_template('ads.html')

@app.route('/devolucoes')
def devolucoes(): 
    """Página de Devoluções"""
    return render_template('devolucoes.html')

@app.route('/estoque_full')
def render_estoque_full_page(): 
    """Página de Estoque Full (Visualização)"""
    return render_template('estoque_full.html', contas=listar_contas())

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Rota de Login Simples"""
    erro = None
    if request.method == 'POST':
        usuario = request.form.get('username')
        senha = request.form.get('password')
        # Login hardcoded simples (pode ser melhorado depois)
        if usuario == "daniel" and senha == "admin":
            return redirect(url_for('dashboard'))
        else:
            erro = "Usuário ou senha incorretos."
    return render_template('login.html', erro=erro)

# ==============================================================================
#                  API: ENDPOINTS DE PROCESSAMENTO
# ==============================================================================

# 1. API DE ENVIO DE VENDAS (ÚNICA)
@app.route('/api/enviar_vendas', methods=['POST'])
def api_enviar_vendas():
    try:
        dados = request.get_json() or {}
        user_id_conta = dados.get('conta_id') 
        
        # Validação
        if not user_id_conta: 
            return jsonify({"sucesso": False, "mensagem": "Selecione uma conta."}), 400
            
        conta = obter_conta(user_id_conta)
        if not conta:
            return jsonify({"sucesso": False, "mensagem": "Conta não encontrada no banco."}), 404
        
        # Lógica de Data
        modo = dados.get('modo', 'ontem')
        hoje = date.today()
        d_ini = d_fim = None

        if modo == 'fds':
            # Pega de Sexta a Domingo
            d_ini = (hoje - timedelta(days=hoje.weekday() + 3)).strftime('%Y-%m-%d')
            d_fim = (hoje - timedelta(days=hoje.weekday() + 1)).strftime('%Y-%m-%d')
        elif modo == 'personalizado':
            d_ini = dados.get('inicio')
            d_fim = dados.get('fim')
        else:
            # Padrão: Ontem
            d_ini = d_fim = (hoje - timedelta(days=1)).strftime('%Y-%m-%d')
        
        # Executa o processamento
        resultado = processar_envio_vendas(
            user_id=user_id_conta,
            google_creds_json=os.environ.get('GOOGLE_CREDENTIALS_JSON'),
            google_creds_file=app.config['GOOGLE_CREDENTIALS_FILE'],
            data_inicio_custom=d_ini, 
            data_fim_custom=d_fim,
            plataforma=dados.get('plataforma'),
            spreadsheet_id_override=conta.get('spreadsheet_id'), 
            sheet_name_override=conta.get('sheet_name') 
        )
        return jsonify(resultado)
        
    except Exception as e:
        traceback.print_exc()
        return jsonify({"sucesso": False, "mensagem": f"Erro interno: {str(e)}"}), 500

# 👇 NOVO ENDPOINT: API SINCRONIZAR TUDO (BACKGROUND) 👇
@app.route('/api/sincronizar_tudo', methods=['POST'])
def api_sincronizar_tudo():
    try:
        dados = request.get_json() or {}
        modo = dados.get('modo', 'ontem')
        hoje = date.today()
        d_ini = d_fim = None

        if modo == 'fds':
            d_ini = (hoje - timedelta(days=hoje.weekday() + 3)).strftime('%Y-%m-%d')
            d_fim = (hoje - timedelta(days=hoje.weekday() + 1)).strftime('%Y-%m-%d')
        elif modo == 'personalizado':
            d_ini = dados.get('inicio')
            d_fim = dados.get('fim')
        else:
            d_ini = d_fim = (hoje - timedelta(days=1)).strftime('%Y-%m-%d')

        contas = listar_contas()
        if not contas:
            return jsonify({"sucesso": False, "log": ["❌ Nenhuma conta cadastrada para sincronizar."]})

        log_iniciados = []
        for conta in contas:
            nome = conta.get('nome_conta', 'Sem Nome')
            plat = conta.get('plataforma', 'Desconhecida').upper()
            log_iniciados.append(f"✅ Sincronização enviada para a fila: {nome} ({plat})")

        # Função Maestro que roda no fundo sem travar o navegador
        def sync_all_bg(contas_list, data_ini, data_fim):
            with app.app_context():
                print("\n===========================================")
                print("⚡ INICIANDO SINCRONIZAÇÃO TOTAL EM BACKGROUND")
                print("===========================================")
                for c in contas_list:
                    try:
                        print(f"-> Maestro enviando ordem para: {c.get('nome_conta')}")
                        processar_envio_vendas(
                            user_id=c.get('user_id'),
                            google_creds_json=os.environ.get('GOOGLE_CREDENTIALS_JSON'),
                            google_creds_file=app.config['GOOGLE_CREDENTIALS_FILE'],
                            data_inicio_custom=data_ini,
                            data_fim_custom=data_fim,
                            plataforma=c.get('plataforma'),
                            spreadsheet_id_override=c.get('spreadsheet_id'),
                            sheet_name_override=c.get('sheet_name')
                        )
                        # Dá um fôlego de 3 segundos entre iniciar uma conta e outra para o servidor não engasgar
                        time.sleep(3)
                    except Exception as e:
                        print(f"Erro Maestro ao processar {c.get('nome_conta')}: {e}")
                print("✅ MAESTRO TERMINOU DE ENVIAR AS ORDENS.")

        # Dispara o Maestro em uma Thread Independente
        threading.Thread(target=sync_all_bg, args=(contas, d_ini, d_fim)).start()

        # Responde IMEDIATAMENTE para a tela da Cris não travar
        log_iniciados.append("🚀 Maestro operando em segundo plano. Suas vendas chegarão na planilha em alguns minutos!")
        return jsonify({"sucesso": True, "log": log_iniciados})

    except Exception as e:
        traceback.print_exc()
        return jsonify({"sucesso": False, "log": [f"❌ Erro Crítico: {str(e)}"]}), 500

# 2. API DE CONTAS (CRUD)
@app.route('/api/accounts', methods=['GET', 'POST'])
def api_accounts():
    if request.method == 'POST':
        # Salvar nova conta
        dados = request.get_json()
        sucesso, msg = salvar_conta(dados)
        return jsonify({"sucesso": sucesso, "mensagem": msg})
    
    # Listar contas
    return jsonify(listar_contas())

@app.route('/api/accounts/<user_id>', methods=['DELETE', 'PUT'])
def api_accounts_id(user_id):
    if request.method == 'DELETE':
        return jsonify({"sucesso": excluir_conta(user_id)})
    
    if request.method == 'PUT':
        sucesso, msg = atualizar_conta(user_id, request.get_json())
        return jsonify({"sucesso": sucesso, "mensagem": msg})

# 3. API FINANCEIRO
@app.route('/processar_financeiro', methods=['POST'])
def processar_financeiro_route():
    try:
        form_data = request.form
        # Roda em background para liberar o usuário
        threading.Thread(target=background_task, args=(processar_estoque_full, (form_data,))).start()
        return jsonify({"sucesso": True, "mensagem": "Processamento iniciado em segundo plano."})
    except Exception as e:
        return jsonify({"sucesso": False, "mensagem": f"Erro: {str(e)}"}), 500

# 4. API PERFORMANCE
@app.route('/api/gerar_performance', methods=['POST'])
def api_gerar_performance():
    try:
        dados = request.get_json()
        
        user_id = dados.get('conta_id')
        tipo = dados.get('tipo_relatorio', 'conversao')
        
        if not user_id:
            return jsonify({"sucesso": False, "mensagem": "ID da conta é obrigatório."})

        opcoes = {
            'data_inicio': dados.get('data_inicio'), 
            'data_fim': dados.get('data_fim')
        }
        
        # Inicia Thread
        threading.Thread(target=background_task, args=(gerar_relatorio_performance_v2, (user_id, tipo, opcoes))).start()
        
        return jsonify({"sucesso": True, "mensagem": "Relatório de Performance iniciado com sucesso."})
    except Exception as e:
        return jsonify({"sucesso": False, "mensagem": str(e)}), 500

# 5. API MARKETING
@app.route('/api/marketing/sync', methods=['POST'])
def api_marketing_sync():
    try:
        d = request.get_json()
        res = buscar_dados_ads_api(d.get('conta_id'), d.get('inicio'), d.get('fim'), d.get('tipo_ads'))
        return jsonify(res)
    except Exception as e:
        return jsonify({"sucesso": False, "mensagem": str(e)}), 500

# 6. API DE LOGS
@app.route('/api/logs', methods=['GET'])
def api_get_logs():
    # Retorna lista de logs para o front-end
    return jsonify(list(SYSTEM_LOGS))

# 7. API UPLOAD
@app.route('/upload_excel_full', methods=['POST'])
def upload_excel_full():
    file = request.files.get('file')
    conta = request.form.get('conta_upload')
    
    if file:
        return jsonify(processar_upload_full(file, conta))
    
    return jsonify({"sucesso": False, "mensagem": "Erro no envio do arquivo."})

# --- NOVO: Endpoint para Disparar Análise de IA Manualmente ---
@app.route('/api/ia/analisar_ads', methods=['POST'])
def api_ia_analisar_ads():
    """Força o Agente D1 a rodar agora mesmo."""
    try:
        threading.Thread(target=background_task, args=(agente_analista_ads, ())).start()
        return jsonify({"sucesso": True, "mensagem": "Análise de IA de ADS iniciada em background."})
    except Exception as e:
        return jsonify({"sucesso": False, "mensagem": str(e)}), 500

# ==============================================================================
#                  ROTAS DE FICHAS TÉCNICAS (CRUD COMPLETO)
# ==============================================================================

@app.route('/fichas', methods=['GET', 'POST'])
def fichas_page_full():
    termo = ''
    resultado = None
    
    if request.method == 'POST':
        termo = request.form.get('busca', '')
        # Busca no banco
        if 'buscar_produto_db' in globals():
            resultado = buscar_produto_db(termo)
            
    return render_template('fichas_view.html', resultado=resultado, termo=termo)

@app.route('/fichas/verificar_sku', methods=['POST'])
def ver_sku():
    try:
        dados = request.get_json()
        sku = dados.get('sku')
        if not sku: return jsonify({"existe": False})
        
        ficha = obter_dados_por_sku(sku)
        if ficha:
            return jsonify({"existe": True, "dados": ficha})
        else:
            return jsonify({"existe": False})
    except:
        return jsonify({"erro": "Falha ao verificar SKU"}), 500

@app.route('/fichas/salvar', methods=['POST'])
def save_ficha():
    try:
        dados = request.form.to_dict()
        arquivo = request.files.get('arquivo_foto')
        
        sucesso, msg = salvar_ficha_db(dados, arquivo)
        
        if sucesso:
            flash(msg, 'success')
        else:
            flash(f"Erro ao salvar: {msg}", 'danger')
            
    except Exception as e:
        flash(f"Erro crítico: {str(e)}", 'danger')
        
    return redirect(url_for('fichas_page_full'))

@app.route('/fichas/excluir/<id_produto>', methods=['POST'])
def del_ficha(id_produto):
    try:
        if excluir_produto_db(id_produto):
            flash("Produto excluído com sucesso.", "success")
        else:
            flash("Erro ao excluir produto.", "danger")
    except Exception as e:
        flash(f"Erro: {e}", "danger")
        
    return redirect(url_for('fichas_page_full'))

@app.route('/fichas/exportar_massa', methods=['POST'])
def exp_massa():
    try:
        ids_str = request.form.get('ids_selecionados')
        mkt = request.form.get('marketplace_alvo')
        sub = request.form.get('subcategoria_alvo')
        
        if not ids_str:
            flash("Nenhum produto selecionado.", "warning")
            return redirect(url_for('fichas_page_full'))
            
        ids_lista = ids_str.split(',')
        
        arquivo_io, nome_arquivo = gerar_excel_marketplace(ids_lista, mkt, sub)
        
        return send_file(
            arquivo_io, 
            as_attachment=True, 
            download_name=nome_arquivo, 
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
    except Exception as e:
        flash(f"Erro na exportação: {str(e)}", "danger")
        return redirect(url_for('fichas_page_full'))

# ==============================================================================
#                  INICIALIZAÇÃO DO SERVIDOR E AGENTES
# ==============================================================================

if __name__ == '__main__':
    # Inicia o Orquestrador de IA em uma thread separada (Background)
    # daemon=True garante que se o app fechar, o robô fecha junto
    print("🤖 Iniciando Orquestrador de IA (Agentes) em segundo plano...")
    thread_ia = threading.Thread(target=iniciar_orquestrador, daemon=True)
    thread_ia.start()

    # Roda o servidor Flask
    print("🚀 Servidor Flask Iniciando na porta 5000...")
    app.run(debug=False, host='0.0.0.0')


