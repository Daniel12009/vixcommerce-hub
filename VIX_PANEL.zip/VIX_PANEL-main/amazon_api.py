import os
import requests
import time
import hmac
import hashlib
import urllib.parse
import re
import pandas as pd
from datetime import datetime
# Assumindo que você tem os seguintes módulos:
from database import obter_conta, atualizar_conta
from google_sheets import append_data_to_sheet, get_gsheet_client

# --- VARIÁVEIS DE CONFIGURAÇÃO ---

# Percentual de Comissão Fixo: 11% sobre o valor total do item.
AMAZON_COMISSAO_PERCENTUAL_FIXO = 0.11 
# Percentual de Imposto/Tarifa Fixo: 0% sobre o valor total do item.
AMAZON_IMPOSTO_PERCENTUAL_FIXO = 0.00 

# --- Funções Auxiliares ---

def clean_sku(sku):
    """
    Limpa o SKU, extraindo o identificador base (ex: FC-133) e descartando 
    os caracteres extras (ex: 'vaivaivaiva' ou '_BUYBOX#1') usando Regex.
    """
    if not sku:
        return ""
    
    sku_upper = str(sku).upper()
    
    # Regex para capturar o padrão de SKU base (duas letras - hifen - dígitos) 
    match = re.match(r'([A-Z]{2}-\d+)', sku_upper) 
    
    if match:
        return match.group(1)
    else:
        return sku_upper 

# Mapeamento de Estados para Tradução (Mantido)
ESTADOS_BRASIL = {
    'AC': 'Acre', 'AL': 'Alagoas', 'AP': 'Amapá', 'AM': 'Amazonas', 'BA': 'Bahia',
    'CE': 'Ceará', 'DF': 'Distrito Federal', 'ES': 'Espírito Santo', 'GO': 'Goiás',
    'MA': 'Maranhão', 'MT': 'Mato Grosso', 'MS': 'Mato Grosso do Sul', 'MG': 'Minas Gerais',
    'PA': 'Pará', 'PB': 'Paraíba', 'PR': 'Paraná', 'PE': 'Pernambuco', 'PI': 'Piauí',
    'RJ': 'Rio de Janeiro', 'RN': 'Rio Grande do Norte', 'RS': 'Rio Grande do Sul',
    'RO': 'Rondônia', 'RR': 'Roraima', 'SC': 'Santa Catarina', 'SP': 'São Paulo',
    'SE': 'Sergipe', 'TO': 'Tocantins'
}

def obter_nome_estado(sigla):
    return ESTADOS_BRASIL.get(sigla.upper(), sigla)

def get_frete_key(sku_clean):
    """Gera a chave do cache de frete baseada no SKU Limpo."""
    return sku_clean

def atualizar_cache_frete(user_id, frete_cache):
    """Salva o cache de frete atualizado no banco de dados."""
    atualizar_conta(user_id, {'frete_cache': frete_cache})

# --- Funções de Assinatura AWS v4 (IAM) (Mantidas) ---

def sign(key, msg):
    return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()

def getSignatureKey(key, dateStamp, regionName, serviceName):
    kDate = sign(('AWS4' + key).encode('utf-8'), dateStamp)
    kRegion = sign(kDate, regionName)
    kService = sign(kRegion, serviceName)
    kSigning = sign(kService, 'aws4_request')
    return kSigning

def get_valid_amazon_token(conta):
    try:
        url_auth = "https://api.amazon.com/auth/o2/token"
        payload = {
            "grant_type": "refresh_token",
            "refresh_token": conta['refresh_token'],
            "client_id": conta['client_id'],
            "client_secret": conta['client_secret']
        }
        resp = requests.post(url_auth, data=payload)
        if resp.status_code != 200: raise Exception(f"Amazon Auth Error: {resp.text}")
        dados = resp.json()
        atualizar_conta(conta['user_id'], {'access_token': dados['access_token']})
        return dados['access_token']
    except Exception as e:
        raise e

def call_amazon_sp_api(access_token, endpoint, query_params, aws_key, aws_secret, region='us-east-1'):
    host = 'sellingpartnerapi-na.amazon.com'
    service = 'execute-api'
    method = 'GET'
    t = datetime.utcnow()
    amz_date = t.strftime('%Y%m%dT%H%M%SZ')
    date_stamp = t.strftime('%Y%m%d')
    canonical_uri = endpoint
    
    canonical_querystring = query_params.strip()
    
    canonical_headers = f'host:{host}\nx-amz-access-token:{access_token}\nx-amz-date:{amz_date}\n'
    signed_headers = 'host;x-amz-access-token;x-amz-date'
    payload_hash = hashlib.sha256(''.encode('utf-8')).hexdigest()
    
    canonical_request = f"{method}\n{canonical_uri}\n{canonical_querystring}\n{canonical_headers}\n{signed_headers}\n{payload_hash}"
    
    algorithm = 'AWS4-HMAC-SHA256'
    credential_scope = f"{date_stamp}/{region}/{service}/aws4_request"
    string_to_sign = f"{algorithm}\n{amz_date}\n{credential_scope}\n{hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()}"
    
    signing_key = getSignatureKey(aws_secret, date_stamp, region, service)
    signature = hmac.new(signing_key, string_to_sign.encode('utf-8'), hashlib.sha256).hexdigest()
    
    authorization_header = f"{algorithm} Credential={aws_key}/{credential_scope}, SignedHeaders={signed_headers}, Signature={signature}"
    
    headers = {
        'x-amz-access-token': access_token,
        'x-amz-date': amz_date,
        'Authorization': authorization_header,
        'host': host
    }
    
    url = f"https://{host}{endpoint}"
    if canonical_querystring:
        url += f"?{canonical_querystring}"
        
    return requests.get(url, headers=headers)

def get_amazon_order_items(access_token, order_id, aws_key, aws_secret):
    endpoint = f"/orders/v0/orders/{order_id}/orderItems"
    resp = call_amazon_sp_api(access_token, endpoint, '', aws_key, aws_secret)
    if resp.status_code == 200:
        return resp.json().get('payload', {}).get('OrderItems', [])
    print(f"ERRO ao obter itens para o pedido {order_id}: {resp.status_code} - {resp.text}")
    return []

# --- Função Principal de Sincronização ---

def executar_sincronizacao_amazon(user_id, google_creds_json, google_creds_file, d_ini, d_fim, spreadsheet_id_override=None, sheet_name_override=None):
    conta = obter_conta(user_id)
    if not conta: return {"sucesso": False, "mensagem": f"Conta Amazon {user_id} não encontrada."}
    
    aws_access_key = os.environ.get('AWS_ACCESS_KEY_ID')
    aws_secret_key = os.environ.get('AWS_SECRET_ACCESS_KEY')
    if not aws_access_key or not aws_secret_key: return {"sucesso": False, "mensagem": "Credenciais AWS IAM não configuradas."}

    try:
        access_token = get_valid_amazon_token(conta)
        
        # --- NOVO: Inicialização do Cache de Frete com valores conhecidos ---
        # Se o cache vier vazio do DB, inicia com seus valores corrigidos.
        default_frete_cache = {
            'FC-133': 6.75,
            'FC-03': 6.50
        }
        frete_cache = conta.get('frete_cache') or default_frete_cache
        # ------------------------------------------------------------------
        
        created_after = f"{d_ini}T00:00:00Z"
        created_before = f"{d_fim}T23:59:59Z"
        marketplace_ids = "A2Q3Y263D00KWC"
        
        query_orders = f"CreatedAfter={urllib.parse.quote(created_after)}&CreatedBefore={urllib.parse.quote(created_before)}&MarketplaceIds={marketplace_ids}"
        resp_orders = call_amazon_sp_api(access_token, "/orders/v0/orders", query_orders, aws_access_key, aws_secret_key)
        
        if resp_orders.status_code != 200: return {"sucesso": False, "mensagem": f"Erro Amazon API (Orders): {resp_orders.text}"}
        
        orders = resp_orders.json().get('payload', {}).get('Orders', [])
        if not orders: return {"sucesso": True, "mensagem": "Nenhuma venda Amazon encontrada."}
        
        client = get_gsheet_client(config={'GOOGLE_CREDENTIALS_FILE': google_creds_file})
        linhas_finais = []
        
        for order in orders:
            order_id = order.get('AmazonOrderId')
            data_pedido = order.get('PurchaseDate', '')[:10] # Formato AAAA-MM-DD
            
            # Lógica FBA/FBM
            fulfillment_channel = order.get('FulfillmentChannel', 'MFN')
            logistica = "FBA" if fulfillment_channel == "AFN" else "FBM"

            sigla_estado = order.get('ShippingAddress', {}).get('StateOrRegion', 'N/A')
            nome_estado_completo = obter_nome_estado(sigla_estado)

            origem = "Amazon"

            order_items = get_amazon_order_items(access_token, order_id, aws_access_key, aws_secret_key)

            for item in order_items:
                seller_sku = item.get('SellerSKU', 'SKU_NA')
                item_asin = item.get('ASIN', 'ASIN_NA')
                
                sku_clean = clean_sku(seller_sku)
                
                item_price_amount = float(item.get('ItemPrice', {}).get('Amount', 0) or 0)
                item_tax_amount = float(item.get('ItemTax', {}).get('Amount', 0) or 0)
                total_item = item_price_amount + item_tax_amount

                quantidade = int(item.get('QuantityOrdered', 0)) 
                if quantidade == 0:
                    continue 
                
                # Frete da API (Apenas para APRENDER novos SKUs)
                shipping_price_amount = float(item.get('ShippingPrice', {}).get('Amount', 0) or 0)
                shipping_tax_amount = float(item.get('ShippingTax', {}).get('Amount', 0) or 0)
                frete_da_api = shipping_price_amount + shipping_tax_amount
                
                # --- Lógica de Frete com Aprendizado/Cache (Baseado no SKU CLEAN) ---
                frete_key = get_frete_key(sku_clean)
                frete_total = frete_da_api 
                
                if frete_key in frete_cache:
                    # Regra 1: Usa o valor do cache (corrigido/aprendido) - ISSO RESOLVE SEU PROBLEMA.
                    frete_total = frete_cache[frete_key]
                elif frete_da_api > 0:
                    # Regra 2: APRENDE o valor da API para SKUs novos que trouxeram frete > 0.
                    frete_cache[frete_key] = frete_da_api
                    frete_total = frete_da_api
                
                # --- Arredondamento e Cálculo Financeiro ---
                frete_total_rounded = round(frete_total, 2)
                
                comissao_total = round(total_item * AMAZON_COMISSAO_PERCENTUAL_FIXO, 2)
                imposto_tarifa_total = round(total_item * AMAZON_IMPOSTO_PERCENTUAL_FIXO, 2) 

                # Linha final para o Google Sheets
                linhas_finais.append([
                    sku_clean,                  # 0. SKU Clean 
                    seller_sku,                 # 1. SKU (Original)
                    data_pedido,                # 2. Data
                    data_pedido,                # 3. Emissao
                    order_id,                   # 4. Pedido
                    origem,                     # 5. Origem
                    item_asin,                  # 6. ID Anuncio 
                    "Padrão",                   # 7. Tipo
                    "",                         # 8. Ads
                    logistica,                  # 9. Logistica (FBA/FBM)
                    round(total_item / quantidade, 2), # 10. Preco Unitário
                    quantidade,                 # 11. Qtd
                    round(total_item, 2),       # 12. Total 
                    frete_total_rounded,        # 13. Frete (Aprendido/Corrigido)
                    imposto_tarifa_total,       # 14. Tarifa (0%)
                    comissao_total,             # 15. Comissao (11% Arredondado)
                    0,                          # 16. Extra
                    conta['nome_conta'],        # 17. Conta
                    nome_estado_completo        # 18. Estado (Traduzido)
                ])

        # 5. Salvar o cache de frete atualizado no DB
        if frete_cache:
            atualizar_cache_frete(user_id, frete_cache)
            
        # 6. Salvar dados no Google Sheets
        if linhas_finais:
            colunas = ["SKU Clean", "SKU", "Data", "Emissao", "Pedido", "Origem", "ID Anuncio", "Tipo", "Ads", "Logistica", "Preco", "Qtd", "Total", "Frete", "Tarifa", "Comissao", "Extra", "Conta", "Estado"]
            df = pd.DataFrame(linhas_finais, columns=colunas)
            
            spreadsheet_id = spreadsheet_id_override or conta.get('spreadsheet_id')
            sheet_name = sheet_name_override or conta.get('sheet_name') or 'VendasAmazon'
            
            append_data_to_sheet(client, df, spreadsheet_id, sheet_name)
            
        return {"sucesso": True, "mensagem": f"Sucesso! {len(linhas_finais)} itens de pedidos Amazon salvos."}
    
    except Exception as e: 
        print(f"ERRO CRÍTICO NA SINCRONIZAÇÃO AMAZON: {e}")
        return {"sucesso": False, "mensagem": str(e)}
