import pandas as pd
import os
import traceback
import io
import base64
import requests
import uuid
import re
import json
from datetime import datetime
import gspread
from google.oauth2.service_account import Credentials

# --- CONFIGURAÇÃO ---
SHEET_ID_BANCO_FICHAS = '1H5NhHUxcYPT7-n1HBONl9jnpEzj0NP-ceSRLTq7cgxA'
NOME_ABA_BANCO = 'FICHAS'
SCOPES = ['https://www.googleapis.com/auth/spreadsheets', 'https://www.googleapis.com/auth/drive.file']

# --- GITHUB ---
GITHUB_TOKEN = os.environ.get('GITHUB_TOKEN') or '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'
GITHUB_USER = 'danielrmonacometais-netizen' 
GITHUB_REPO = 'Sistema_Fotos_Fichas' 
GITHUB_BRANCH = 'main' 

def get_gsheet_client():
    """
    Tenta autenticar usando arquivo físico ou conteúdo JSON na variável de ambiente.
    """
    creds = None
    
    # 1. Tenta pegar o caminho do arquivo definido na variável
    credentials_file = os.environ.get('GOOGLE_CREDENTIALS_FILE', 'credentials.json')
    
    # 2. Se o arquivo existe, usa ele
    if os.path.exists(credentials_file):
        try:
            creds = Credentials.from_service_account_file(credentials_file, scopes=SCOPES)
        except Exception as e:
            print(f"⚠️ Erro ao ler arquivo {credentials_file}: {e}")

    # 3. Se não deu certo, tenta ler o JSON direto da variável GOOGLE_CREDENTIALS_JSON (Ideal para Render)
    if not creds:
        json_content = os.environ.get('GOOGLE_CREDENTIALS_JSON')
        if json_content:
            try:
                # Se vier como string, converte para dict
                if isinstance(json_content, str):
                    info = json.loads(json_content)
                else:
                    info = json_content
                creds = Credentials.from_service_account_info(info, scopes=SCOPES)
            except Exception as e:
                print(f"⚠️ Erro ao ler JSON da variável de ambiente: {e}")

    if creds:
        return gspread.authorize(creds)
    
    print("❌ ERRO CRÍTICO: Nenhuma credencial do Google encontrada (Arquivo ou Variável).")
    return None

# --- COLUNAS DB ---
COLUNAS_DB = [
    'id', 'sku_produto', 'nome_produto', 'id_lote', 'data_chegada', 'produto_novo',
    'cor_produto', 'acabamento_produto', 'prod_material', 'material_bica',
    'tipo_torneira', 'lugar_colocacao', 'indicacao_uso', 
    'tipo_acionamento_geral', 'local_acionamento_geral', 'material_acionador_geral',
    'tipo_abertura_acionador', 
    'modo_spray', 'modo_chuveiro', 'produto_flexivel', 'altura_flexivel', 'largura_flexivel',
    'tipo_abertura', 
    'dupla_torneira', 'tipo_dupla_torneira', 'tipo_acionamento_dupla_torneira', 
    'local_acionamento_dupla_torneira', 'material_acionador_dupla',
    'comprimento_dupla_torneira', 'altura_queda_agua_dupla_torneira', 'largura_dupla_torneira',
    'prod_altura_cm', 'prod_largura_cm', 'prod_profund_cm', 'prod_peso_kg', 
    'altura_queda_agua', 'furo_de_instalação', 'largura_rosca', 'material_rosca', 'comprimento_rosca',
    'apoio_torneira', 'apoio_altura', 'apoio_comprimento', 'apoio_largura',
    'emb_material', 'emb_altura_cm', 'emb_largura_cm', 'emb_comprim_cm', 'emb_peso_kg',
    'ean_gtin', 'ncm_codigo', 
    'lista_acessorios', 'foto_url', 'observacoes', 'data_registro'
]

def init_db():
    print("🔄 Inicializando Banco de Dados (Planilha)...")
    client = get_gsheet_client()
    if not client: 
        print("❌ Falha na conexão ao iniciar DB.")
        return
    try:
        sh = client.open_by_key(SHEET_ID_BANCO_FICHAS)
        try: 
            ws = sh.worksheet(NOME_ABA_BANCO)
            print(f"✅ Aba '{NOME_ABA_BANCO}' encontrada.")
        except: 
            print(f"⚠️ Aba '{NOME_ABA_BANCO}' não existe. Criando...")
            ws = sh.add_worksheet(title=NOME_ABA_BANCO, rows=1000, cols=len(COLUNAS_DB))
        
        # Verifica cabeçalho
        if not ws.row_values(1): 
            ws.append_row(COLUNAS_DB)
            print("✅ Cabeçalhos criados.")
            
    except Exception as e: 
        print(f"--- ERRO DB INIT: {e}")

def obter_dados_por_sku(sku):
    try:
        client = get_gsheet_client()
        sh = client.open_by_key(SHEET_ID_BANCO_FICHAS)
        ws = sh.worksheet(NOME_ABA_BANCO)
        todos = ws.get_all_records() # Exige cabeçalho na linha 1
        
        # Filtra pelo SKU
        matches = [row for row in todos if str(row.get('sku_produto', '')).strip().upper() == str(sku).strip().upper()]
        
        if matches: return matches[-1] # Retorna o último encontrado
        return None
    except Exception as e:
        print(f"Erro ao buscar SKU {sku}: {e}")
        return None

def upload_imagem_github(file_obj, sku):
    try:
        if not file_obj: return ""
        ext = file_obj.filename.split('.')[-1]
        nome_arquivo = f"{sku}_{uuid.uuid4().hex[:6]}.{ext}"
        caminho_github = f"UP-imagem/{nome_arquivo}"
        conteudo_base64 = base64.b64encode(file_obj.read()).decode('utf-8')
        url_api = f"https://api.github.com/repos/{GITHUB_USER}/{GITHUB_REPO}/contents/{caminho_github}"
        headers = {"Authorization": f"token {GITHUB_TOKEN}", "Accept": "application/vnd.github.v3+json"}
        data = {"message": f"Upload foto {sku}", "content": conteudo_base64, "branch": GITHUB_BRANCH}
        response = requests.put(url_api, json=data, headers=headers)
        if response.status_code in [200, 201]:
            return f"https://raw.githubusercontent.com/{GITHUB_USER}/{GITHUB_REPO}/{GITHUB_BRANCH}/{caminho_github}"
        return ""
    except: return ""

def corrigir_link_drive(url):
    if not url or "drive.google.com" not in str(url): return str(url)
    match = re.search(r'/file/d/([a-zA-Z0-9_-]+)', str(url))
    if match: return f"https://drive.google.com/uc?export=view&id={match.group(1)}"
    return url

def salvar_ficha_db(dados, arquivo_foto=None):
    try:
        client = get_gsheet_client()
        if not client: return False, "Erro conexão Google (Credenciais)"
        
        sh = client.open_by_key(SHEET_ID_BANCO_FICHAS)
        try: ws = sh.worksheet(NOME_ABA_BANCO)
        except: ws = sh.add_worksheet(title=NOME_ABA_BANCO, rows=1000, cols=len(COLUNAS_DB))
        
        registros = ws.get_all_values()
        
        # Lógica de ID melhorada: Pega o maior ID existente + 1
        novo_id = 1
        if len(registros) > 1: # Tem cabeçalho e dados
            ids = [int(r[0]) for r in registros[1:] if r[0].isdigit()]
            if ids: novo_id = max(ids) + 1
        
        link_foto = dados.get('foto_url', '')
        
        # Upload Github (se houver arquivo novo)
        if arquivo_foto and hasattr(arquivo_foto, 'filename') and arquivo_foto.filename != '':
            nl = upload_imagem_github(arquivo_foto, dados.get('sku_produto', 'SEM_SKU'))
            if nl: link_foto = nl
        else: 
            link_foto = corrigir_link_drive(link_foto)
        
        linha = []
        for col in COLUNAS_DB:
            if col == 'id': linha.append(str(novo_id))
            elif col == 'data_registro': linha.append(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            elif col == 'foto_url': linha.append(link_foto)
            else:
                val = dados.get(col, '')
                linha.append(str(val).strip() if val else '')
        
        ws.append_row(linha)
        return True, f"Ficha Salva com Sucesso! ID: {novo_id}"
        
    except Exception as e:
        traceback.print_exc()
        return False, f"Erro ao salvar: {str(e)}"

# --- EXPORTAÇÃO INTELIGENTE ---
def gerar_excel_marketplace(lista_ids, marketplace, subcategoria=None):
    try:
        if not isinstance(lista_ids, list): lista_ids = [lista_ids]
        client = get_gsheet_client()
        if not client: return None, None
        
        sh = client.open_by_key(SHEET_ID_BANCO_FICHAS)
        ws = sh.worksheet(NOME_ABA_BANCO)
        todos_dados = ws.get_all_records()
        
        prods = [p for p in todos_dados if str(p.get('id')) in map(str, lista_ids)]
        if not prods: return None, None

        mapa_usado = {}

        # === 1. MERCADO LIVRE (TORNEIRAS) ===
        if marketplace == 'mercadolivre' and subcategoria == 'torneiras':
            mapa_usado = {
                'Código universal de produto': 'ean_gtin',
                'SKU': 'sku_produto',
                'Título': 'nome_produto',
                'Quantidade de caracteres': '', 
                'Condição': lambda p: 'Novo',
                'Varia por: Cor': 'cor_produto',
                'Varia por: Acabamento': 'acabamento_produto',
                'Fotos': 'foto_url',
                'Estoque': lambda p: '100', 
                'Preço [R$]': '', 
                'Descrição': lambda p: f"PRODUTO: {p.get('nome_produto')}\n\nMATERIAL: {p.get('prod_material')}\nMEDIDAS: {p.get('prod_altura_cm')}cm x {p.get('prod_largura_cm')}cm\n\n{p.get('observacoes')}",
                'Largura (cm)': 'emb_largura_cm',
                'Altura (cm)': 'emb_altura_cm',
                'Profundidade (cm)': 'emb_comprim_cm',
                'Peso físico (kg)': 'emb_peso_kg',
                'Tipo de anúncio': lambda p: 'Clássico',
                'Forma de envio': lambda p: 'Mercado Envios',
                'Retirar pessoalmente': lambda p: 'Não',
                'Tipo de garantia': lambda p: 'Garantia do vendedor',
                'Tempo de garantia': lambda p: '90',
                'Unidade de Tempo de garantia': lambda p: 'dias',
                'Marca': lambda p: 'Genérica',
                'Modelo': 'sku_produto',
                'Materiais': 'prod_material',
                'Lugar de colocação': 'lugar_colocacao',
                'Tipo de controle da torneira': 'tipo_acionamento_geral',
                'Quantidade de furos': 'furo_de_instalação'
            }

        # === 2. SHOPEE (PADRÃO) ===
        elif marketplace == 'shopee':
            mapa_usado = {
                'Parent SKU': 'sku_produto',
                'Product Name': 'nome_produto',
                'Description': 'observacoes',
                'Cover Image': 'foto_url',
                'Weight': 'emb_peso_kg',
                'Length': 'emb_comprim_cm',
                'Width': 'emb_largura_cm',
                'Height': 'emb_altura_cm'
            }
        
        else:
            return None, None # Categoria não encontrada

        # Gera Lista
        lista_final = []
        for p in prods:
            linha = {}
            for col_mkt, col_db in mapa_usado.items():
                if callable(col_db): linha[col_mkt] = col_db(p)
                elif col_db in p: linha[col_mkt] = p[col_db]
                else: linha[col_mkt] = col_db
            lista_final.append(linha)

        df = pd.DataFrame(lista_final)
        
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, index=False)
        output.seek(0)
        
        nome_arq = f"{marketplace}_{subcategoria}_LOTE_{len(lista_ids)}.xlsx"
        return output, nome_arq

    except Exception as e:
        traceback.print_exc()
        return None, None

def buscar_produto_db(termo=None):
    try:
        client = get_gsheet_client()
        if not client: return []
        sh = client.open_by_key(SHEET_ID_BANCO_FICHAS)
        ws = sh.worksheet(NOME_ABA_BANCO)
        todos = ws.get_all_records()
        if not todos: return []
        if not termo or not termo.strip(): return list(reversed(todos[-20:]))
        termo = termo.lower().strip()
        res = [i for i in todos if termo in str(i.get('sku_produto','')).lower() or termo in str(i.get('nome_produto','')).lower()]
        return list(reversed(res))
    except: return []

def excluir_produto_db(id_produto):
    try:
        client = get_gsheet_client()
        sh = client.open_by_key(SHEET_ID_BANCO_FICHAS)
        ws = sh.worksheet(NOME_ABA_BANCO)
        cell = ws.find(str(id_produto), in_column=1)
        if cell:
            ws.delete_rows(cell.row)
            return True
        return False
    except: return False
